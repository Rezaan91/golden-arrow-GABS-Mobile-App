PLACEHOLDER ASSETS

Expo will use default icons/splash if these files are missing.

For production, add:
- icon.png (1024x1024)
- splash.png (1284x2778)
- adaptive-icon.png (1024x1024)
- favicon.png (48x48)

Current setup will work without these files.
