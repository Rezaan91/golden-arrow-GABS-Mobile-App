import React from 'react';
import { View, Text, StyleSheet, Platform } from 'react-native';

// Web-compatible map component
export default function WebCompatibleMap({ region, children, style, ...props }) {
  if (Platform.OS === 'web') {
    return (
      <View style={[styles.webMapContainer, style]}>
        <Text style={styles.webMapText}>🗺️ Map View</Text>
        <Text style={styles.webMapLocation}>
          {region ? `${region.latitude.toFixed(4)}, ${region.longitude.toFixed(4)}` : 'Cape Town, South Africa'}
        </Text>
        <Text style={styles.webMapNote}>Interactive map available on mobile</Text>
      </View>
    );
  }

  // On mobile, dynamically import MapView to avoid web build issues
  try {
    const MapView = require('react-native-maps').default;
    return (
      <MapView style={style} region={region} {...props}>
        {children}
      </MapView>
    );
  } catch (error) {
    return (
      <View style={[styles.webMapContainer, style]}>
        <Text style={styles.webMapText}>🗺️ Map Unavailable</Text>
        <Text style={styles.webMapNote}>Please install react-native-maps</Text>
      </View>
    );
  }
}

export function WebCompatibleMarker({ coordinate, title, pinColor }) {
  if (Platform.OS === 'web') {
    return null; // Markers handled by parent on web
  }
  
  try {
    const { Marker } = require('react-native-maps');
    return <Marker coordinate={coordinate} title={title} pinColor={pinColor} />;
  } catch (error) {
    return null;
  }
}

const styles = StyleSheet.create({
  webMapContainer: {
    backgroundColor: '#2a2a3e',
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: 12,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.1)',
    minHeight: 200,
  },
  webMapText: {
    fontSize: 24,
    color: '#fff',
    marginBottom: 8,
  },
  webMapLocation: {
    fontSize: 14,
    color: 'rgba(255,255,255,0.7)',
    marginBottom: 4,
  },
  webMapNote: {
    fontSize: 12,
    color: 'rgba(255,255,255,0.5)',
    fontStyle: 'italic',
  },
});