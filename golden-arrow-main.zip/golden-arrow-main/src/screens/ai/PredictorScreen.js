import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  ProgressBarAndroid,
  ActivityIndicator,
} from 'react-native';

export default function PredictorScreen() {
  const [prediction, setPrediction] = useState({
    currentBalance: 245.75,
    averageDailySpend: 31.50,
    daysRemaining: 7.8,
    nextPredictedEmpty: 'December 3, 2024',
    confidence: 0.87,
    recommendedRefill: 150,
    loading: false,
  });

  const [showDetails, setShowDetails] = useState(false);

  const handleRefresh = async () => {
    setPrediction(prev => ({ ...prev, loading: true }));
    try {
      await new Promise(resolve => setTimeout(resolve, 1500));
      setPrediction(prev => ({
        ...prev,
        loading: false,
        confidence: 0.89,
      }));
    } finally {
      setPrediction(prev => ({ ...prev, loading: false }));
    }
  };

  return (
    <ScrollView style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.title}>🧠 Smart Refill Predictor</Text>
        <Text style={styles.subtitle}>AI-powered balance prediction</Text>
      </View>

      <View style={styles.predictionCard}>
        <View style={styles.cardContent}>
          <Text style={styles.label}>Balance Will Last</Text>
          <Text style={styles.mainValue}>{prediction.daysRemaining.toFixed(1)} days</Text>
          <Text style={styles.subtext}>Until approximately {prediction.nextPredictedEmpty}</Text>
        </View>
        <View style={styles.indicator}>
          <Text style={styles.indicatorValue}>
            {Math.round(prediction.daysRemaining * 10) / 10}d
          </Text>
        </View>
      </View>

      <View style={styles.metrics}>
        <View style={styles.metric}>
          <Text style={styles.metricLabel}>Current Balance</Text>
          <Text style={styles.metricValue}>R {prediction.currentBalance.toFixed(2)}</Text>
        </View>
        <View style={styles.divider} />
        <View style={styles.metric}>
          <Text style={styles.metricLabel}>Daily Average</Text>
          <Text style={styles.metricValue}>R {prediction.averageDailySpend.toFixed(2)}</Text>
        </View>
        <View style={styles.divider} />
        <View style={styles.metric}>
          <Text style={styles.metricLabel}>Confidence</Text>
          <Text style={styles.metricValue}>{(prediction.confidence * 100).toFixed(0)}%</Text>
        </View>
      </View>

      <View style={styles.recommendationCard}>
        <Text style={styles.recommendationTitle}>💡 Recommended Action</Text>
        <Text style={styles.recommendationText}>
          Based on your usage patterns, we recommend topping up R {prediction.recommendedRefill} to ensure you have 2 weeks of credit.
        </Text>
        <TouchableOpacity style={styles.recommendationButton}>
          <Text style={styles.recommendationButtonText}>Top Up Now</Text>
        </TouchableOpacity>
      </View>

      <TouchableOpacity
        style={styles.detailsToggle}
        onPress={() => setShowDetails(!showDetails)}
      >
        <Text style={styles.detailsToggleText}>
          {showDetails ? '▼' : '▶'} How We Calculate This
        </Text>
      </TouchableOpacity>

      {showDetails && (
        <View style={styles.detailsBox}>
          <Text style={styles.detailsTitle}>Prediction Method</Text>
          <View style={styles.detailItem}>
            <Text style={styles.detailItemTitle}>1. Data Collection</Text>
            <Text style={styles.detailItemText}>
              We analyze your transaction history over the past 30 days to identify spending patterns.
            </Text>
          </View>
          <View style={styles.detailItem}>
            <Text style={styles.detailItemTitle}>2. Pattern Analysis</Text>
            <Text style={styles.detailItemText}>
              Our ML model calculates your average daily spending and identifies weekly variations.
            </Text>
          </View>
          <View style={styles.detailItem}>
            <Text style={styles.detailItemTitle}>3. Prediction</Text>
            <Text style={styles.detailItemText}>
              Using linear regression, we project when your balance will reach zero.
            </Text>
          </View>
          <View style={styles.detailItem}>
            <Text style={styles.detailItemTitle}>4. Confidence Score</Text>
            <Text style={styles.detailItemText}>
              Confidence reflects prediction accuracy based on consistency of your spending habits.
            </Text>
          </View>
          <Text style={styles.confidenceNote}>
            Current confidence: {(prediction.confidence * 100).toFixed(0)}% - 
            {prediction.confidence > 0.85 ? ' Very accurate' : prediction.confidence > 0.70 ? ' Accurate' : ' May vary'}
          </Text>
        </View>
      )}

      <View style={styles.historyCard}>
        <Text style={styles.historyTitle}>Last 7 Days Spending</Text>
        <View style={styles.chartPlaceholder}>
          <Text style={styles.chartText}>📊 Daily spending chart</Text>
          <View style={styles.chart}>
            {[30, 32, 35, 28, 31, 33, 30].map((val, idx) => (
              <View key={idx} style={styles.bar}>
                <View style={[styles.barFill, { height: `${(val / 35) * 100}%` }]} />
                <Text style={styles.barLabel}>{idx + 1}</Text>
              </View>
            ))}
          </View>
        </View>
      </View>

      <TouchableOpacity
        style={[styles.refreshButton, prediction.loading && styles.refreshButtonDisabled]}
        onPress={handleRefresh}
        disabled={prediction.loading}
      >
        {prediction.loading ? (
          <ActivityIndicator size="small" color="#fff" />
        ) : (
          <Text style={styles.refreshButtonText}>🔄 Refresh Prediction</Text>
        )}
      </TouchableOpacity>

      <View style={styles.privacyBox}>
        <Text style={styles.privacyText}>
          🔒 Your data stays private. Predictions are calculated locally and never shared without consent.
        </Text>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5',
  },
  header: {
    backgroundColor: '#0066CC',
    paddingVertical: 20,
    paddingHorizontal: 15,
  },
  title: {
    fontSize: 22,
    fontWeight: 'bold',
    color: '#fff',
  },
  subtitle: {
    fontSize: 13,
    color: '#e0e0ff',
    marginTop: 4,
  },
  predictionCard: {
    backgroundColor: '#fff',
    marginHorizontal: 15,
    marginVertical: 15,
    borderRadius: 12,
    padding: 20,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    elevation: 4,
  },
  cardContent: {
    flex: 1,
  },
  label: {
    fontSize: 12,
    color: '#999',
    marginBottom: 5,
  },
  mainValue: {
    fontSize: 32,
    fontWeight: 'bold',
    color: '#0066CC',
  },
  subtext: {
    fontSize: 12,
    color: '#666',
    marginTop: 8,
  },
  indicator: {
    width: 80,
    height: 80,
    borderRadius: 40,
    backgroundColor: '#e6f2ff',
    justifyContent: 'center',
    alignItems: 'center',
    marginLeft: 15,
  },
  indicatorValue: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#0066CC',
  },
  metrics: {
    backgroundColor: '#fff',
    marginHorizontal: 15,
    borderRadius: 8,
    elevation: 2,
    overflow: 'hidden',
  },
  metric: {
    paddingHorizontal: 15,
    paddingVertical: 12,
  },
  metricLabel: {
    fontSize: 12,
    color: '#999',
    marginBottom: 5,
  },
  metricValue: {
    fontSize: 16,
    fontWeight: '700',
    color: '#333',
  },
  divider: {
    height: 1,
    backgroundColor: '#f0f0f0',
  },
  recommendationCard: {
    backgroundColor: '#fff9e6',
    marginHorizontal: 15,
    marginVertical: 15,
    paddingHorizontal: 15,
    paddingVertical: 15,
    borderRadius: 8,
    borderLeftWidth: 4,
    borderLeftColor: '#ffb300',
  },
  recommendationTitle: {
    fontSize: 14,
    fontWeight: '700',
    color: '#996600',
    marginBottom: 8,
  },
  recommendationText: {
    fontSize: 13,
    color: '#666',
    lineHeight: 18,
    marginBottom: 12,
  },
  recommendationButton: {
    backgroundColor: '#ffb300',
    paddingVertical: 10,
    paddingHorizontal: 15,
    borderRadius: 6,
    alignItems: 'center',
  },
  recommendationButtonText: {
    fontSize: 13,
    fontWeight: '600',
    color: '#fff',
  },
  detailsToggle: {
    paddingHorizontal: 15,
    paddingVertical: 12,
    marginTop: 10,
  },
  detailsToggleText: {
    fontSize: 14,
    fontWeight: '600',
    color: '#0066CC',
  },
  detailsBox: {
    backgroundColor: '#fff',
    marginHorizontal: 15,
    marginVertical: 10,
    paddingHorizontal: 15,
    paddingVertical: 15,
    borderRadius: 8,
  },
  detailsTitle: {
    fontSize: 14,
    fontWeight: '700',
    color: '#333',
    marginBottom: 12,
  },
  detailItem: {
    marginBottom: 12,
  },
  detailItemTitle: {
    fontSize: 13,
    fontWeight: '600',
    color: '#0066CC',
    marginBottom: 4,
  },
  detailItemText: {
    fontSize: 12,
    color: '#666',
    lineHeight: 16,
  },
  confidenceNote: {
    fontSize: 12,
    color: '#999',
    marginTop: 12,
    fontStyle: 'italic',
  },
  historyCard: {
    backgroundColor: '#fff',
    marginHorizontal: 15,
    marginVertical: 15,
    paddingHorizontal: 15,
    paddingVertical: 15,
    borderRadius: 8,
    elevation: 2,
  },
  historyTitle: {
    fontSize: 14,
    fontWeight: '700',
    color: '#333',
    marginBottom: 12,
  },
  chartPlaceholder: {
    alignItems: 'center',
  },
  chartText: {
    fontSize: 12,
    color: '#999',
    marginBottom: 10,
  },
  chart: {
    flexDirection: 'row',
    alignItems: 'flex-end',
    justifyContent: 'space-around',
    width: '100%',
    height: 120,
    gap: 6,
  },
  bar: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'flex-end',
  },
  barFill: {
    width: '100%',
    backgroundColor: '#0066CC',
    borderRadius: 4,
  },
  barLabel: {
    fontSize: 10,
    color: '#999',
    marginTop: 4,
  },
  refreshButton: {
    marginHorizontal: 15,
    marginVertical: 15,
    paddingVertical: 12,
    backgroundColor: '#0066CC',
    borderRadius: 8,
    alignItems: 'center',
  },
  refreshButtonDisabled: {
    opacity: 0.7,
  },
  refreshButtonText: {
    fontSize: 14,
    fontWeight: '600',
    color: '#fff',
  },
  privacyBox: {
    backgroundColor: '#e6f2ff',
    marginHorizontal: 15,
    marginBottom: 20,
    paddingHorizontal: 12,
    paddingVertical: 12,
    borderRadius: 8,
  },
  privacyText: {
    fontSize: 12,
    color: '#0066CC',
    lineHeight: 16,
  },
});
