import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, TextInput, TouchableOpacity, Alert, ScrollView, ActivityIndicator } from 'react-native';
import * as Location from 'expo-location';
import { Ionicons } from '@expo/vector-icons';
import AsyncStorage from '@react-native-async-storage/async-storage';

export default function ShareLocationScreen({ navigation }) {
  const [contacts, setContacts] = useState([]);
  const [selectedContact, setSelectedContact] = useState(null);
  const [destination, setDestination] = useState('');
  const [loading, setLoading] = useState(false);
  const [sharing, setSharing] = useState(false);

  useEffect(() => {
    loadContacts();
  }, []);

  const loadContacts = async () => {
    try {
      const userData = await AsyncStorage.getItem('userData');
      if (userData) {
        const user = JSON.parse(userData);
        setContacts([
          { id: '1', name: 'Mom', phone: '0821234567' },
          { id: '2', name: 'Dad', phone: '0827654321' },
          { id: '3', name: 'Sister', phone: '0839876543' },
        ]);
      }
    } catch (error) {
      console.log('Load contacts error:', error);
    }
  };

  const handleStartSharing = async () => {
    if (!selectedContact) {
      Alert.alert('Error', 'Please select a contact');
      return;
    }
    if (!destination.trim()) {
      Alert.alert('Error', 'Please enter destination address');
      return;
    }

    setLoading(true);
    try {
      const { status } = await Location.requestForegroundPermissionsAsync();
      if (status !== 'granted') {
        Alert.alert('Permission Denied', 'Location access required');
        setLoading(false);
        return;
      }

      const location = await Location.getCurrentPositionAsync({});
      const userData = await AsyncStorage.getItem('userData');
      const user = JSON.parse(userData);

      const shareData = {
        id: Date.now().toString(),
        sender: user.firstName + ' ' + user.surname,
        senderPhone: user.phone,
        recipient: selectedContact.phone,
        destination: destination,
        startLat: location.coords.latitude,
        startLon: location.coords.longitude,
        currentLat: location.coords.latitude,
        currentLon: location.coords.longitude,
        startTime: Date.now(),
        expiresAt: Date.now() + 7200000,
      };

      await AsyncStorage.setItem('activeShare', JSON.stringify(shareData));

      Alert.alert('✅ Sharing Started', `Sharing location with ${selectedContact.name}\nDestination: ${destination}`, [
        { text: 'OK', onPress: () => navigation.goBack() }
      ]);

      setSharing(true);
    } catch (error) {
      Alert.alert('Error', error.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <ScrollView style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.title}>Share Location</Text>
        <Text style={styles.subtitle}>Send your live location to a trusted contact</Text>
      </View>

      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Select Contact</Text>
        {contacts.map(contact => (
          <TouchableOpacity
            key={contact.id}
            style={[styles.contactCard, selectedContact?.id === contact.id && styles.contactCardSelected]}
            onPress={() => setSelectedContact(contact)}
          >
            <View style={styles.contactAvatar}>
              <Text style={styles.avatarText}>{contact.name[0]}</Text>
            </View>
            <View style={styles.contactInfo}>
              <Text style={styles.contactName}>{contact.name}</Text>
              <Text style={styles.contactPhone}>{contact.phone}</Text>
            </View>
            {selectedContact?.id === contact.id && (
              <Ionicons name="checkmark-circle" size={24} color="#4CAF50" />
            )}
          </TouchableOpacity>
        ))}
      </View>

      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Destination Address</Text>
        <TextInput
          style={styles.input}
          placeholder="Enter destination address"
          placeholderTextColor="rgba(255,255,255,0.5)"
          value={destination}
          onChangeText={setDestination}
          multiline
          numberOfLines={3}
        />
        <Text style={styles.hint}>Used to auto-stop sharing when you arrive</Text>
      </View>

      <View style={styles.infoBox}>
        <Ionicons name="information-circle" size={20} color="#667eea" />
        <View style={styles.infoContent}>
          <Text style={styles.infoTitle}>How It Works</Text>
          <Text style={styles.infoText}>• Contact receives SMS with share link</Text>
          <Text style={styles.infoText}>• Your location updates every 10 seconds</Text>
          <Text style={styles.infoText}>• Sharing stops when you reach destination</Text>
          <Text style={styles.infoText}>• Auto-stops after 2 hours for safety</Text>
        </View>
      </View>

      <TouchableOpacity
        style={[styles.button, loading && styles.buttonDisabled]}
        onPress={handleStartSharing}
        disabled={loading}
      >
        {loading ? (
          <ActivityIndicator size="small" color="#fff" />
        ) : (
          <>
            <Ionicons name="location" size={20} color="#fff" />
            <Text style={styles.buttonText}>Start Sharing Location</Text>
          </>
        )}
      </TouchableOpacity>

      <View style={{ height: 20 }} />
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#1a1a2e' },
  header: { backgroundColor: '#667eea', paddingVertical: 30, paddingHorizontal: 20, paddingTop: 50 },
  title: { fontSize: 24, fontWeight: '900', color: '#fff', marginBottom: 5 },
  subtitle: { fontSize: 14, color: 'rgba(255,255,255,0.8)' },
  section: { paddingHorizontal: 20, marginTop: 20 },
  sectionTitle: { fontSize: 16, fontWeight: '700', color: '#fff', marginBottom: 12 },
  contactCard: { backgroundColor: 'rgba(255,255,255,0.1)', borderWidth: 2, borderColor: 'rgba(255,255,255,0.2)', borderRadius: 16, padding: 15, marginBottom: 10, flexDirection: 'row', alignItems: 'center' },
  contactCardSelected: { borderColor: '#4CAF50', backgroundColor: 'rgba(76, 175, 80, 0.1)' },
  contactAvatar: { width: 50, height: 50, borderRadius: 25, backgroundColor: '#667eea', alignItems: 'center', justifyContent: 'center', marginRight: 15 },
  avatarText: { fontSize: 20, fontWeight: '700', color: '#fff' },
  contactInfo: { flex: 1 },
  contactName: { fontSize: 14, fontWeight: '600', color: '#fff', marginBottom: 4 },
  contactPhone: { fontSize: 12, color: 'rgba(255,255,255,0.6)' },
  input: { backgroundColor: 'rgba(255,255,255,0.1)', borderWidth: 1, borderColor: 'rgba(255,255,255,0.2)', borderRadius: 12, paddingHorizontal: 15, paddingVertical: 12, fontSize: 14, color: '#fff', marginBottom: 8 },
  hint: { fontSize: 11, color: 'rgba(255,255,255,0.5)' },
  infoBox: { flexDirection: 'row', backgroundColor: 'rgba(102, 126, 234, 0.2)', margin: 20, padding: 15, borderRadius: 12, gap: 12 },
  infoContent: { flex: 1 },
  infoTitle: { fontSize: 13, fontWeight: '600', color: '#667eea', marginBottom: 8 },
  infoText: { fontSize: 11, color: 'rgba(255,255,255,0.8)', marginBottom: 4 },
  button: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 10, backgroundColor: '#4CAF50', marginHorizontal: 20, paddingVertical: 16, borderRadius: 12 },
  buttonDisabled: { opacity: 0.6 },
  buttonText: { fontSize: 16, fontWeight: '700', color: '#fff' },
});
