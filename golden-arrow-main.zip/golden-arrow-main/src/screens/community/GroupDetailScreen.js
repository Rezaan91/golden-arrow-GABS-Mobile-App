import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  FlatList,
  TextInput,
  Alert,
} from 'react-native';

export default function GroupDetailScreen({ route }) {
  const { group } = route.params;
  const [updates, setUpdates] = useState([
    {
      id: 1,
      author: 'Thabiso M.',
      message: 'Route 102 buses running 15 mins late due to traffic at Foreshore.',
      type: 'delay',
      timestamp: '5 mins ago',
      reactions: { thumbsUp: 12, warning: 3 },
    },
    {
      id: 2,
      author: 'Amandla K.',
      message: '⚠️ SAFETY ALERT: Suspicious activity at Civic Centre stop. Avoid if possible.',
      type: 'safety',
      timestamp: '20 mins ago',
      reactions: { warning: 28, thumbsUp: 5 },
    },
    {
      id: 3,
      author: 'Linda P.',
      message: 'The bus at 14:30 is overcrowded - expect delays boarding',
      type: 'crowd',
      timestamp: '32 mins ago',
      reactions: { warning: 15 },
    },
  ]);

  const [newMessage, setNewMessage] = useState('');

  const handleSendMessage = () => {
    if (!newMessage.trim()) return;

    Alert.alert('Message sent', 'Your update has been shared with ' + group.members.toLocaleString() + ' members');
    setNewMessage('');
  };

  const renderUpdate = ({ item }) => (
    <View style={styles.updateCard}>
      <View style={[styles.typeIndicator, styles[`type${item.type}`]]} />
      <View style={styles.updateContent}>
        <View style={styles.updateHeader}>
          <Text style={styles.authorName}>{item.author}</Text>
          <Text style={styles.timestamp}>{item.timestamp}</Text>
        </View>
        <Text style={styles.message}>{item.message}</Text>
        <View style={styles.reactions}>
          {Object.entries(item.reactions).map(([emoji, count]) => (
            <TouchableOpacity key={emoji} style={styles.reactionButton}>
              <Text style={styles.reactionEmoji}>{emoji === 'thumbsUp' ? '👍' : '⚠️'}</Text>
              <Text style={styles.reactionCount}>{count}</Text>
            </TouchableOpacity>
          ))}
        </View>
      </View>
    </View>
  );

  return (
    <View style={styles.container}>
      <ScrollView style={styles.updatesList}>
        <View style={styles.groupHeader}>
          <Text style={styles.groupTitle}>{group.name}</Text>
          <View style={styles.groupBadges}>
            <View style={styles.badge}>
              <Text style={styles.badgeText}>{group.members.toLocaleString()} members</Text>
            </View>
            <View style={styles.badge}>
              <Text style={styles.badgeText}>{group.alerts} active alerts</Text>
            </View>
          </View>
        </View>

        <View style={styles.safetyTips}>
          <Text style={styles.safetyTitle}>🚨 Group Guidelines</Text>
          <Text style={styles.safetyText}>
            • Share accurate, real-time updates • Respect all members • Report inappropriate content • Focus on commute safety
          </Text>
        </View>

        <View style={styles.updatesSection}>
          <Text style={styles.sectionTitle}>Recent Updates</Text>
          <FlatList
            data={updates}
            renderItem={renderUpdate}
            keyExtractor={item => item.id.toString()}
            scrollEnabled={false}
          />
        </View>
      </ScrollView>

      <View style={styles.inputContainer}>
        <TextInput
          style={styles.input}
          placeholder="Share a delay, safety concern, or update..."
          value={newMessage}
          onChangeText={setNewMessage}
          multiline
          maxHeight={100}
        />
        <TouchableOpacity
          style={[styles.sendButton, !newMessage.trim() && styles.sendButtonDisabled]}
          onPress={handleSendMessage}
          disabled={!newMessage.trim()}
        >
          <Text style={styles.sendButtonText}>Send</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5',
  },
  updatesList: {
    flex: 1,
  },
  groupHeader: {
    backgroundColor: '#0066CC',
    padding: 15,
  },
  groupTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#fff',
    marginBottom: 10,
  },
  groupBadges: {
    flexDirection: 'row',
    gap: 10,
  },
  badge: {
    backgroundColor: 'rgba(255,255,255,0.2)',
    paddingHorizontal: 10,
    paddingVertical: 6,
    borderRadius: 4,
  },
  badgeText: {
    fontSize: 12,
    color: '#fff',
    fontWeight: '600',
  },
  safetyTips: {
    backgroundColor: '#fff9e6',
    marginHorizontal: 15,
    marginVertical: 15,
    padding: 12,
    borderRadius: 8,
    borderLeftWidth: 4,
    borderLeftColor: '#ffb300',
  },
  safetyTitle: {
    fontSize: 13,
    fontWeight: '700',
    color: '#996600',
    marginBottom: 6,
  },
  safetyText: {
    fontSize: 12,
    color: '#666',
    lineHeight: 16,
  },
  updatesSection: {
    paddingHorizontal: 15,
    paddingBottom: 15,
  },
  sectionTitle: {
    fontSize: 14,
    fontWeight: '600',
    color: '#333',
    marginBottom: 10,
  },
  updateCard: {
    flexDirection: 'row',
    backgroundColor: '#fff',
    marginBottom: 10,
    paddingHorizontal: 12,
    paddingVertical: 12,
    borderRadius: 8,
    elevation: 1,
  },
  typeIndicator: {
    width: 4,
    borderRadius: 2,
    marginRight: 10,
  },
  typedelay: {
    backgroundColor: '#ffb300',
  },
  typesafety: {
    backgroundColor: '#cc0000',
  },
  typecrowd: {
    backgroundColor: '#ff6600',
  },
  updateContent: {
    flex: 1,
  },
  updateHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 6,
  },
  authorName: {
    fontSize: 13,
    fontWeight: '600',
    color: '#333',
  },
  timestamp: {
    fontSize: 11,
    color: '#999',
  },
  message: {
    fontSize: 13,
    color: '#666',
    lineHeight: 18,
    marginBottom: 8,
  },
  reactions: {
    flexDirection: 'row',
    gap: 8,
  },
  reactionButton: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#f0f0f0',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 4,
    gap: 4,
  },
  reactionEmoji: {
    fontSize: 14,
  },
  reactionCount: {
    fontSize: 11,
    fontWeight: '600',
    color: '#666',
  },
  inputContainer: {
    backgroundColor: '#fff',
    borderTopWidth: 1,
    borderTopColor: '#eee',
    padding: 12,
    flexDirection: 'row',
    gap: 8,
  },
  input: {
    flex: 1,
    borderWidth: 1,
    borderColor: '#ddd',
    borderRadius: 8,
    paddingHorizontal: 12,
    paddingVertical: 10,
    fontSize: 14,
    maxHeight: 100,
    backgroundColor: '#f5f5f5',
  },
  sendButton: {
    backgroundColor: '#0066CC',
    paddingHorizontal: 16,
    paddingVertical: 10,
    borderRadius: 8,
    justifyContent: 'center',
  },
  sendButtonDisabled: {
    opacity: 0.5,
  },
  sendButtonText: {
    color: '#fff',
    fontSize: 14,
    fontWeight: '600',
  },
});
