import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, Switch, ScrollView, Alert } from 'react-native';
import * as Location from 'expo-location';
import * as SMS from 'expo-sms';
import { shareLocation, updateLocation, stopSharing } from '../../services/communityService';

export default function ShareLocationScreen({ navigation }) {
  const [contacts, setContacts] = useState([
    { id: 1, name: 'Mom', phone: '0821234567', selected: true },
    { id: 2, name: 'Dad', phone: '0827654321', selected: true },
    { id: 3, name: 'Sister', phone: '0839876543', selected: false },
  ]);
  const [autoStop, setAutoStop] = useState(true);
  const [currentLocation, setCurrentLocation] = useState(null);
  const [region, setRegion] = useState({
    latitude: -33.9249,
    longitude: 18.4241,
    latitudeDelta: 0.05,
    longitudeDelta: 0.05,
  });

  useEffect(() => {
    getCurrentLocation();
  }, []);

  const getCurrentLocation = async () => {
    try {
      const coords = { latitude: -33.9249, longitude: 18.4241 }; // Mock location for web
      setCurrentLocation(coords);
      setRegion({ ...coords, latitudeDelta: 0.05, longitudeDelta: 0.05 });
    } catch (error) {
      console.log('Location error:', error);
    }
  };

  const toggleContact = (id) => {
    setContacts(contacts.map(c => c.id === id ? { ...c, selected: !c.selected } : c));
  };

  const startSharing = async () => {
    const selected = contacts.filter(c => c.selected);
    if (selected.length === 0) {
      Alert.alert('No Contacts', 'Please select at least one trusted contact');
      return;
    }
    
    Alert.alert(
      'Location Sharing Started',
      `Location shared with ${selected.length} contact(s). (Demo mode - no SMS sent)`,
      [{ text: 'OK', onPress: () => navigation.goBack() }]
    );
  };

  return (
    <View style={styles.container}>
      <View style={styles.mapContainer}>
        <View style={styles.webMap}>
          <Text style={styles.webMapText}>🗺️ Map View</Text>
          <Text style={styles.webMapLocation}>
            Cape Town, South Africa
          </Text>
          <Text style={styles.webMapNote}>Interactive map available on mobile</Text>
        </View>
      </View>
      
      <ScrollView style={styles.content}>
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Trusted Contacts</Text>
          {contacts.map(contact => (
            <TouchableOpacity
              key={contact.id}
              style={styles.contactItem}
              onPress={() => toggleContact(contact.id)}
            >
              <View style={styles.contactInfo}>
                <Text style={styles.contactName}>{contact.selected ? '☑' : '☐'} {contact.name}</Text>
                <Text style={styles.contactPhone}>{contact.phone}</Text>
              </View>
            </TouchableOpacity>
          ))}
        </View>

        <View style={styles.section}>
          <View style={styles.settingRow}>
            <View>
              <Text style={styles.settingLabel}>Auto-stop on arrival</Text>
              <Text style={styles.settingHint}>Stop sharing when you reach destination</Text>
            </View>
            <Switch value={autoStop} onValueChange={setAutoStop} trackColor={{ false: '#ccc', true: '#4CAF50' }} />
          </View>
        </View>

        <View style={styles.emergencyBox}>
          <Text style={styles.emergencyTitle}>🚨 Emergency Hotline</Text>
          <Text style={styles.emergencyNumber}>0800 656 463</Text>
          <Text style={styles.emergencyNote}>Golden Arrow 24/7 Support</Text>
        </View>

        <TouchableOpacity style={styles.shareButton} onPress={startSharing}>
          <Text style={styles.shareButtonText}>Start Sharing Location</Text>
        </TouchableOpacity>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#1a1a2e' },
  mapContainer: { height: 300, width: '100%' },
  webMap: { 
    flex: 1, 
    backgroundColor: '#2a2a3e',
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: 12,
    margin: 15,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.1)',
  },
  webMapText: { fontSize: 24, color: '#fff', marginBottom: 8 },
  webMapLocation: { fontSize: 14, color: 'rgba(255,255,255,0.7)', marginBottom: 4 },
  webMapNote: { fontSize: 12, color: 'rgba(255,255,255,0.5)', fontStyle: 'italic' },
  content: { flex: 1 },
  section: { marginHorizontal: 15, marginTop: 20 },
  sectionTitle: { fontSize: 16, fontWeight: '700', color: '#fff', marginBottom: 12 },
  contactItem: { backgroundColor: 'rgba(255,255,255,0.1)', padding: 15, borderRadius: 12, marginBottom: 10 },
  contactInfo: { flexDirection: 'column' },
  contactName: { fontSize: 16, fontWeight: '600', color: '#fff', marginBottom: 4 },
  contactPhone: { fontSize: 13, color: 'rgba(255,255,255,0.7)' },
  settingRow: { backgroundColor: 'rgba(255,255,255,0.1)', padding: 15, borderRadius: 12, flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  settingLabel: { fontSize: 14, fontWeight: '600', color: '#fff' },
  settingHint: { fontSize: 12, color: 'rgba(255,255,255,0.6)', marginTop: 4 },
  emergencyBox: { backgroundColor: 'rgba(204, 0, 0, 0.2)', marginHorizontal: 15, marginTop: 20, padding: 15, borderRadius: 12, borderLeftWidth: 4, borderLeftColor: '#cc0000', alignItems: 'center' },
  emergencyTitle: { fontSize: 16, fontWeight: '700', color: '#fff', marginBottom: 8 },
  emergencyNumber: { fontSize: 24, fontWeight: '900', color: '#fff', marginBottom: 4 },
  emergencyNote: { fontSize: 12, color: 'rgba(255,255,255,0.7)' },
  shareButton: { backgroundColor: '#4CAF50', marginHorizontal: 15, marginVertical: 20, paddingVertical: 16, borderRadius: 12, alignItems: 'center' },
  shareButtonText: { color: '#fff', fontSize: 16, fontWeight: '700' },
});