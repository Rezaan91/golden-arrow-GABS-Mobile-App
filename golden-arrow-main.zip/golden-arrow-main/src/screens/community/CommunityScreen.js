import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, Alert } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import MapView, { Marker } from 'react-native-maps';
import AsyncStorage from '@react-native-async-storage/async-storage';

export default function CommunityScreen({ navigation }) {
  const [activeShares, setActiveShares] = useState([]);
  const [selectedShare, setSelectedShare] = useState(null);

  useEffect(() => {
    const unsubscribe = navigation.addListener('focus', () => {
      loadActiveShares();
    });
    return unsubscribe;
  }, [navigation]);

  const loadActiveShares = async () => {
    try {
      const share = await AsyncStorage.getItem('activeShare');
      if (share) {
        const shareData = JSON.parse(share);
        if (shareData.expiresAt > Date.now()) {
          setActiveShares([shareData]);
        } else {
          await AsyncStorage.removeItem('activeShare');
          setActiveShares([]);
        }
      }
    } catch (error) {
      console.log('Load shares error:', error);
    }
  };

  const calculateDistance = (lat1, lon1, lat2, lon2) => {
    const R = 6371;
    const dLat = (lat2 - lat1) * Math.PI / 180;
    const dLon = (lon2 - lon1) * Math.PI / 180;
    const a = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
              Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *
              Math.sin(dLon / 2) * Math.sin(dLon / 2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    return (R * c * 1000).toFixed(0);
  };

  const handleStopSharing = async (shareId) => {
    Alert.alert('Stop Sharing', 'Stop sharing your location?', [
      { text: 'Cancel' },
      {
        text: 'Stop',
        onPress: async () => {
          await AsyncStorage.removeItem('activeShare');
          setActiveShares([]);
          setSelectedShare(null);
          Alert.alert('✅ Stopped', 'Location sharing stopped');
        }
      }
    ]);
  };

  return (
    <ScrollView style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.title}>Community Safety</Text>
        <Text style={styles.subtitle}>Share & track locations with trusted contacts</Text>
      </View>

      {activeShares.length === 0 ? (
        <View style={styles.emptyState}>
          <Ionicons name="location" size={64} color="rgba(255,255,255,0.2)" />
          <Text style={styles.emptyTitle}>No Active Shares</Text>
          <Text style={styles.emptyText}>Start sharing your location with a trusted contact</Text>
          <TouchableOpacity
            style={styles.startButton}
            onPress={() => navigation.navigate('ShareLocation')}
          >
            <Ionicons name="add-circle" size={20} color="#fff" />
            <Text style={styles.startButtonText}>Start Sharing</Text>
          </TouchableOpacity>
        </View>
      ) : (
        <>
          {activeShares.map(share => {
            const distance = calculateDistance(
              share.startLat, share.startLon,
              share.currentLat, share.currentLon
            );
            const timeElapsed = Math.floor((Date.now() - share.startTime) / 60000);

            return (
              <View key={share.id} style={styles.shareCard}>
                <View style={styles.shareHeader}>
                  <View style={styles.senderInfo}>
                    <View style={styles.avatar}>
                      <Text style={styles.avatarText}>{share.sender[0]}</Text>
                    </View>
                    <View>
                      <Text style={styles.senderName}>{share.sender}</Text>
                      <Text style={styles.shareStatus}>🟢 Live</Text>
                    </View>
                  </View>
                  <TouchableOpacity onPress={() => handleStopSharing(share.id)}>
                    <Ionicons name="close-circle" size={24} color="#f5576c" />
                  </TouchableOpacity>
                </View>

                <View style={styles.mapContainer}>
                  <MapView
                    style={styles.map}
                    region={{
                      latitude: share.currentLat,
                      longitude: share.currentLon,
                      latitudeDelta: 0.05,
                      longitudeDelta: 0.05,
                    }}
                  >
                    <Marker
                      coordinate={{
                        latitude: share.currentLat,
                        longitude: share.currentLon,
                      }}
                      title={share.sender}
                      pinColor="#f5576c"
                    />
                  </MapView>
                </View>

                <View style={styles.shareDetails}>
                  <View style={styles.detailRow}>
                    <Ionicons name="flag" size={16} color="#667eea" />
                    <View style={styles.detailContent}>
                      <Text style={styles.detailLabel}>Destination</Text>
                      <Text style={styles.detailValue}>{share.destination}</Text>
                    </View>
                  </View>

                  <View style={styles.detailRow}>
                    <Ionicons name="navigate" size={16} color="#4CAF50" />
                    <View style={styles.detailContent}>
                      <Text style={styles.detailLabel}>Distance Traveled</Text>
                      <Text style={styles.detailValue}>{distance}m</Text>
                    </View>
                  </View>

                  <View style={styles.detailRow}>
                    <Ionicons name="time" size={16} color="#FFA500" />
                    <View style={styles.detailContent}>
                      <Text style={styles.detailLabel}>Time Elapsed</Text>
                      <Text style={styles.detailValue}>{timeElapsed} min</Text>
                    </View>
                  </View>
                </View>

                <TouchableOpacity
                  style={styles.viewButton}
                  onPress={() => setSelectedShare(selectedShare?.id === share.id ? null : share)}
                >
                  <Text style={styles.viewButtonText}>
                    {selectedShare?.id === share.id ? 'Hide Details' : 'View Full Map'}
                  </Text>
                </TouchableOpacity>
              </View>
            );
          })}

          <TouchableOpacity
            style={styles.addButton}
            onPress={() => navigation.navigate('ShareLocation')}
          >
            <Ionicons name="add" size={20} color="#fff" />
            <Text style={styles.addButtonText}>Share with Another Contact</Text>
          </TouchableOpacity>
        </>
      )}

      <View style={{ height: 20 }} />
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#1a1a2e' },
  header: { backgroundColor: '#667eea', paddingVertical: 30, paddingHorizontal: 20, paddingTop: 50 },
  title: { fontSize: 28, fontWeight: '900', color: '#fff', marginBottom: 5 },
  subtitle: { fontSize: 14, color: 'rgba(255,255,255,0.8)' },
  emptyState: { alignItems: 'center', paddingVertical: 60, paddingHorizontal: 20 },
  emptyTitle: { fontSize: 18, fontWeight: '700', color: '#fff', marginTop: 20, marginBottom: 8 },
  emptyText: { fontSize: 14, color: 'rgba(255,255,255,0.6)', textAlign: 'center', marginBottom: 30 },
  startButton: { flexDirection: 'row', alignItems: 'center', gap: 10, backgroundColor: '#4CAF50', paddingHorizontal: 20, paddingVertical: 12, borderRadius: 12 },
  startButtonText: { fontSize: 14, fontWeight: '600', color: '#fff' },
  shareCard: { margin: 20, backgroundColor: 'rgba(255,255,255,0.1)', borderWidth: 1, borderColor: 'rgba(255,255,255,0.2)', borderRadius: 20, padding: 16, overflow: 'hidden' },
  shareHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 15 },
  senderInfo: { flexDirection: 'row', alignItems: 'center', gap: 12 },
  avatar: { width: 45, height: 45, borderRadius: 22.5, backgroundColor: '#667eea', alignItems: 'center', justifyContent: 'center' },
  avatarText: { fontSize: 18, fontWeight: '700', color: '#fff' },
  senderName: { fontSize: 14, fontWeight: '600', color: '#fff', marginBottom: 4 },
  shareStatus: { fontSize: 12, color: '#4CAF50' },
  mapContainer: { height: 200, borderRadius: 12, overflow: 'hidden', marginBottom: 15 },
  map: { width: '100%', height: '100%' },
  shareDetails: { gap: 12, marginBottom: 15 },
  detailRow: { flexDirection: 'row', alignItems: 'center', gap: 12 },
  detailContent: { flex: 1 },
  detailLabel: { fontSize: 11, color: 'rgba(255,255,255,0.6)', marginBottom: 2 },
  detailValue: { fontSize: 13, fontWeight: '600', color: '#fff' },
  viewButton: { backgroundColor: 'rgba(102, 126, 234, 0.3)', paddingVertical: 12, borderRadius: 12, alignItems: 'center' },
  viewButtonText: { fontSize: 14, fontWeight: '600', color: '#667eea' },
  addButton: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 10, backgroundColor: '#667eea', marginHorizontal: 20, marginTop: 20, paddingVertical: 14, borderRadius: 12 },
  addButtonText: { fontSize: 14, fontWeight: '600', color: '#fff' },
});
