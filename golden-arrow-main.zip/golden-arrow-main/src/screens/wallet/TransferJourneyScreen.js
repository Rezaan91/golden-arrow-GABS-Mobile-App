import React, { useState, useContext } from 'react';
import { View, Text, StyleSheet, TextInput, TouchableOpacity, Alert, ScrollView, ActivityIndicator } from 'react-native';
import { WalletContext } from '../../context/WalletContext';

export default function TransferJourneyScreen({ navigation }) {
  const { walletState, setWalletState } = useContext(WalletContext);
  const [recipientPhone, setRecipientPhone] = useState('');
  const [journeys, setJourneys] = useState('');
  const [loading, setLoading] = useState(false);

  const handleTransfer = () => {
    if (!recipientPhone || recipientPhone.length !== 10) {
      Alert.alert('Error', 'Enter a valid 10-digit phone number');
      return;
    }
    if (!journeys || parseInt(journeys) < 1) {
      Alert.alert('Error', 'Enter number of journeys to transfer');
      return;
    }
    const amount = parseInt(journeys);
    if (amount > walletState.journeysRemaining) {
      Alert.alert('Error', `You only have ${walletState.journeysRemaining} journeys`);
      return;
    }

    setLoading(true);
    Alert.alert(
      'Confirm Transfer',
      `Transfer ${amount} journey${amount > 1 ? 's' : ''} to ${recipientPhone}?`,
      [
        { text: 'Cancel', onPress: () => setLoading(false) },
        {
          text: 'Transfer',
          onPress: () => {
            setWalletState(prev => ({
              ...prev,
              journeysRemaining: prev.journeysRemaining - amount,
              history: [
                {
                  id: Date.now().toString(),
                  type: 'transfer',
                  recipient: recipientPhone,
                  quantity: amount,
                  date: new Date().toISOString(),
                  journeysRemaining: prev.journeysRemaining - amount,
                },
                ...prev.history
              ]
            }));
            Alert.alert('✅ Success', `${amount} journey${amount > 1 ? 's' : ''} transferred to ${recipientPhone}!`, [
              { text: 'OK', onPress: () => { setLoading(false); navigation.goBack(); } }
            ]);
          }
        }
      ]
    );
  };

  return (
    <ScrollView style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.title}>Transfer Journeys</Text>
        <Text style={styles.subtitle}>Send journeys to another user</Text>
      </View>

      <View style={styles.balanceCard}>
        <Text style={styles.balanceLabel}>Your Balance</Text>
        <Text style={styles.balanceValue}>{walletState.journeysRemaining} journeys</Text>
      </View>

      <View style={styles.form}>
        <Text style={styles.label}>Recipient Phone Number *</Text>
        <TextInput
          style={styles.input}
          placeholder="0812345678"
          value={recipientPhone}
          onChangeText={setRecipientPhone}
          keyboardType="phone-pad"
          maxLength={10}
          editable={!loading}
        />
        <Text style={styles.hint}>Must be verified/linked account</Text>

        <Text style={styles.label}>Number of Journeys *</Text>
        <TextInput
          style={styles.input}
          placeholder="1"
          value={journeys}
          onChangeText={setJourneys}
          keyboardType="number-pad"
          editable={!loading}
        />
        <Text style={styles.hint}>Max: {walletState.journeysRemaining}</Text>

        <View style={styles.infoBox}>
          <Text style={styles.infoTitle}>ℹ️ Important</Text>
          <Text style={styles.infoText}>• Transfers are instant and free</Text>
          <Text style={styles.infoText}>• Recipient must have verified account</Text>
          <Text style={styles.infoText}>• Cannot be reversed once confirmed</Text>
          <Text style={styles.infoText}>• Transfer is not transferable</Text>
        </View>

        <TouchableOpacity
          style={[styles.button, loading && styles.buttonDisabled]}
          onPress={handleTransfer}
          disabled={loading}
        >
          {loading ? (
            <ActivityIndicator size="small" color="#fff" />
          ) : (
            <Text style={styles.buttonText}>Transfer Journeys</Text>
          )}
        </TouchableOpacity>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#1a1a2e' },
  header: { backgroundColor: '#f5576c', paddingVertical: 30, paddingHorizontal: 20, paddingTop: 50 },
  title: { fontSize: 24, fontWeight: '900', color: '#fff' },
  subtitle: { fontSize: 14, color: 'rgba(255,255,255,0.8)', marginTop: 5 },
  balanceCard: { backgroundColor: 'rgba(255,255,255,0.1)', margin: 20, padding: 20, borderRadius: 16, alignItems: 'center' },
  balanceLabel: { fontSize: 12, color: 'rgba(255,255,255,0.7)', marginBottom: 5 },
  balanceValue: { fontSize: 32, fontWeight: '900', color: '#fff' },
  form: { paddingHorizontal: 20, paddingBottom: 20 },
  label: { fontSize: 14, fontWeight: '600', color: '#fff', marginBottom: 8, marginTop: 15 },
  input: { backgroundColor: 'rgba(255,255,255,0.1)', borderWidth: 1, borderColor: 'rgba(255,255,255,0.2)', borderRadius: 12, paddingHorizontal: 15, paddingVertical: 12, fontSize: 16, color: '#fff', marginBottom: 5 },
  hint: { fontSize: 11, color: 'rgba(255,255,255,0.5)', marginBottom: 15 },
  infoBox: { backgroundColor: 'rgba(102, 126, 234, 0.2)', padding: 15, borderRadius: 12, marginBottom: 20, marginTop: 10 },
  infoTitle: { fontSize: 13, fontWeight: '600', color: '#667eea', marginBottom: 8 },
  infoText: { fontSize: 12, color: 'rgba(255,255,255,0.8)', marginBottom: 4 },
  button: { backgroundColor: '#667eea', paddingVertical: 16, borderRadius: 12, alignItems: 'center', marginTop: 10 },
  buttonDisabled: { opacity: 0.7 },
  buttonText: { color: '#fff', fontSize: 16, fontWeight: '700' },
});
