import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  TextInput,
  ActivityIndicator,
  Alert,
} from 'react-native';

export default function RefillScreen({ navigation }) {
  const [amount, setAmount] = useState('');
  const [paymentMethod, setPaymentMethod] = useState('snapScan');
  const [loading, setLoading] = useState(false);

  const quickAmounts = [50, 100, 150, 200, 250];

  const handleRefill = async () => {
    if (!amount) {
      Alert.alert('Error', 'Please enter an amount');
      return;
    }

    setLoading(true);
    try {
      // Simulate payment processing
      await new Promise(resolve => setTimeout(resolve, 2000));
      Alert.alert('Success', `R ${amount} has been added to your wallet!`, [
        { text: 'OK', onPress: () => navigation.goBack() },
      ]);
    } catch (error) {
      Alert.alert('Error', 'Payment failed: ' + error.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <ScrollView style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.title}>Top Up Your Wallet</Text>
        <Text style={styles.subtitle}>Quick and secure payment</Text>
      </View>

      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Quick Amount Select</Text>
        <View style={styles.quickButtons}>
          {quickAmounts.map(amt => (
            <TouchableOpacity
              key={amt}
              style={[styles.quickButton, amount === amt.toString() && styles.quickButtonActive]}
              onPress={() => setAmount(amt.toString())}
            >
              <Text style={[styles.quickButtonText, amount === amt.toString() && styles.quickButtonTextActive]}>
                R{amt}
              </Text>
            </TouchableOpacity>
          ))}
        </View>
      </View>

      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Or Enter Custom Amount</Text>
        <View style={styles.inputGroup}>
          <Text style={styles.label}>Amount (R)</Text>
          <View style={styles.inputContainer}>
            <Text style={styles.currencySymbol}>R</Text>
            <TextInput
              style={styles.input}
              placeholder="0.00"
              value={amount}
              onChangeText={setAmount}
              keyboardType="decimal-pad"
              editable={!loading}
            />
          </View>
        </View>
      </View>

      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Payment Method</Text>
        <View style={styles.paymentOptions}>
          {[
            { id: 'snapScan', label: 'SnapScan', icon: '📱' },
            { id: 'zapper', label: 'Zapper', icon: '💳' },
            { id: 'eft', label: 'Bank Transfer (EFT)', icon: '🏦' },
          ].map(method => (
            <TouchableOpacity
              key={method.id}
              style={[styles.paymentOption, paymentMethod === method.id && styles.paymentOptionActive]}
              onPress={() => setPaymentMethod(method.id)}
            >
              <Text style={styles.paymentIcon}>{method.icon}</Text>
              <Text style={styles.paymentLabel}>{method.label}</Text>
            </TouchableOpacity>
          ))}
        </View>
      </View>

      <View style={styles.feeBox}>
        <View style={styles.feeRow}>
          <Text style={styles.feeLabel}>Subtotal:</Text>
          <Text style={styles.feeValue}>R {(amount || 0)}</Text>
        </View>
        <View style={styles.feeRow}>
          <Text style={styles.feeLabel}>Processing Fee:</Text>
          <Text style={styles.feeValue}>R {((amount || 0) * 0.015).toFixed(2)}</Text>
        </View>
        <View style={styles.divider} />
        <View style={styles.feeRow}>
          <Text style={styles.totalLabel}>Total:</Text>
          <Text style={styles.totalValue}>R {((amount || 0) * 1.015).toFixed(2)}</Text>
        </View>
      </View>

      <TouchableOpacity
        style={[styles.button, loading && styles.buttonDisabled]}
        onPress={handleRefill}
        disabled={loading || !amount}
      >
        {loading ? (
          <ActivityIndicator size="small" color="#fff" />
        ) : (
          <Text style={styles.buttonText}>Proceed to Payment</Text>
        )}
      </TouchableOpacity>

      <TouchableOpacity onPress={() => navigation.goBack()} style={styles.cancelButton}>
        <Text style={styles.cancelButtonText}>Cancel</Text>
      </TouchableOpacity>

      <View style={styles.securityBox}>
        <Text style={styles.securityText}>🔒 Your payment details are encrypted and secure. We never store your card information.</Text>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5',
  },
  header: {
    paddingTop: 20,
    paddingBottom: 20,
    paddingHorizontal: 15,
    backgroundColor: '#0066CC',
  },
  title: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#fff',
  },
  subtitle: {
    fontSize: 12,
    color: '#e0e0ff',
    marginTop: 5,
  },
  section: {
    marginHorizontal: 15,
    marginVertical: 15,
  },
  sectionTitle: {
    fontSize: 14,
    fontWeight: '600',
    color: '#333',
    marginBottom: 12,
  },
  quickButtons: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 10,
  },
  quickButton: {
    flex: 1,
    minWidth: '30%',
    paddingVertical: 12,
    borderWidth: 2,
    borderColor: '#ddd',
    borderRadius: 8,
    alignItems: 'center',
    backgroundColor: '#fff',
  },
  quickButtonActive: {
    borderColor: '#0066CC',
    backgroundColor: '#e6f2ff',
  },
  quickButtonText: {
    fontSize: 14,
    fontWeight: '600',
    color: '#666',
  },
  quickButtonTextActive: {
    color: '#0066CC',
  },
  inputGroup: {
    marginBottom: 15,
  },
  label: {
    fontSize: 12,
    fontWeight: '600',
    color: '#333',
    marginBottom: 8,
  },
  inputContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#ddd',
    borderRadius: 8,
    backgroundColor: '#fff',
  },
  currencySymbol: {
    paddingLeft: 15,
    fontSize: 18,
    fontWeight: '600',
    color: '#333',
  },
  input: {
    flex: 1,
    paddingHorizontal: 10,
    paddingVertical: 12,
    fontSize: 16,
  },
  paymentOptions: {
    flexDirection: 'column',
    gap: 10,
  },
  paymentOption: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 12,
    paddingHorizontal: 15,
    borderWidth: 2,
    borderColor: '#ddd',
    borderRadius: 8,
    backgroundColor: '#fff',
  },
  paymentOptionActive: {
    borderColor: '#0066CC',
    backgroundColor: '#e6f2ff',
  },
  paymentIcon: {
    fontSize: 20,
    marginRight: 10,
  },
  paymentLabel: {
    fontSize: 14,
    fontWeight: '600',
    color: '#333',
  },
  feeBox: {
    backgroundColor: '#fff',
    marginHorizontal: 15,
    marginVertical: 15,
    padding: 15,
    borderRadius: 8,
    elevation: 2,
  },
  feeRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 8,
  },
  feeLabel: {
    fontSize: 13,
    color: '#666',
  },
  feeValue: {
    fontSize: 13,
    fontWeight: '600',
    color: '#333',
  },
  divider: {
    height: 1,
    backgroundColor: '#eee',
    marginVertical: 8,
  },
  totalLabel: {
    fontSize: 14,
    fontWeight: '700',
    color: '#333',
  },
  totalValue: {
    fontSize: 14,
    fontWeight: '700',
    color: '#0066CC',
  },
  button: {
    backgroundColor: '#0066CC',
    marginHorizontal: 15,
    paddingVertical: 14,
    borderRadius: 8,
    alignItems: 'center',
  },
  buttonDisabled: {
    opacity: 0.5,
  },
  buttonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: '600',
  },
  cancelButton: {
    marginHorizontal: 15,
    marginTop: 10,
    paddingVertical: 12,
    alignItems: 'center',
  },
  cancelButtonText: {
    color: '#0066CC',
    fontSize: 14,
    fontWeight: '600',
  },
  securityBox: {
    backgroundColor: '#e6f2ff',
    marginHorizontal: 15,
    marginVertical: 20,
    paddingVertical: 12,
    paddingHorizontal: 12,
    borderRadius: 8,
  },
  securityText: {
    fontSize: 12,
    color: '#0066CC',
    lineHeight: 16,
  },
});
