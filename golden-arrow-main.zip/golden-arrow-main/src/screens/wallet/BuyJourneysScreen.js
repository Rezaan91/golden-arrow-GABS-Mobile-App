import React, { useState, useContext } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, Alert } from 'react-native';
import { WalletContext } from '../../context/WalletContext';

export default function BuyJourneysScreen({ navigation }) {
  const { walletState, setWalletState } = useContext(WalletContext);
  const [selected, setSelected] = useState('weekly');
  const [location, setLocation] = useState('khayelitsha');
  const [loading, setLoading] = useState(false);

  const locations = {
    khayelitsha: { name: 'Khayelitsha to Cape Town', weekly: 240, monthly: 1150 },
    phillipi: { name: 'Phillipi to Cape Town', weekly: 180, monthly: 850 },
    bellville: { name: 'Bellville', weekly: 200, monthly: 950 },
  };

  const packages = [
    { id: 'weekly', name: 'Weekly Ticket', journeys: 10 },
    { id: 'monthly', name: 'Monthly Ticket', journeys: 48 },
  ];

  const currentLocation = locations[location];
  const price = selected === 'weekly' ? currentLocation.weekly : currentLocation.monthly;
  const journeys = packages.find(p => p.id === selected).journeys;

  const handlePurchase = () => {
    setLoading(true);
    Alert.alert(
      'Confirm Purchase',
      `Buy ${packages.find(p => p.id === selected).name}\n${journeys} journeys for R${price}?`,
      [
        { text: 'Cancel', onPress: () => setLoading(false) },
        {
          text: 'Buy Now',
          onPress: () => {
            const newBalance = walletState.journeysRemaining + journeys;
            setWalletState(prev => ({
              ...prev,
              journeysRemaining: newBalance,
              ticketType: selected,
              history: [
                {
                  id: Date.now().toString(),
                  type: 'purchase',
                  description: `Bought ${journeys} journeys (${packages.find(p => p.id === selected).name}) for R${price}`,
                  date: new Date().toISOString(),
                  journeysRemaining: newBalance,
                  syncStatus: 'synced'
                },
                ...prev.history
              ]
            }));
            Alert.alert('✅ Success', `${journeys} journeys added to your account!`, [
              { text: 'OK', onPress: () => { setLoading(false); navigation.goBack(); } }
            ]);
          }
        }
      ]
    );
  };

  return (
    <ScrollView style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.title}>Buy Journey Tickets</Text>
        <Text style={styles.subtitle}>Choose your package</Text>
      </View>

      <View style={styles.currentBalance}>
        <Text style={styles.balanceLabel}>Current Balance</Text>
        <Text style={styles.balanceValue}>{walletState.journeysRemaining} journeys</Text>
      </View>

      <View style={styles.section}>
        <Text style={styles.label}>Select Location</Text>
        <View style={styles.picker}>
          {Object.entries(locations).map(([key, loc]) => (
            <TouchableOpacity
              key={key}
              style={[styles.locationOption, location === key && styles.locationOptionActive]}
              onPress={() => setLocation(key)}
            >
              <Text style={[styles.locationText, location === key && styles.locationTextActive]}>
                {loc.name}
              </Text>
            </TouchableOpacity>
          ))}
        </View>
      </View>

      {packages.map(pkg => (
        <TouchableOpacity
          key={pkg.id}
          style={[styles.package, selected === pkg.id && styles.packageSelected]}
          onPress={() => setSelected(pkg.id)}
        >
          <Text style={styles.packageName}>{pkg.name}</Text>
          <Text style={styles.packageJourneys}>{pkg.journeys} Journeys</Text>
          <Text style={styles.packagePrice}>R{pkg.id === 'weekly' ? currentLocation.weekly : currentLocation.monthly}</Text>
          <Text style={styles.packagePer}>R{((pkg.id === 'weekly' ? currentLocation.weekly : currentLocation.monthly) / pkg.journeys).toFixed(2)} per journey</Text>
        </TouchableOpacity>
      ))}

      <View style={styles.infoBox}>
        <Text style={styles.infoTitle}>💡 How It Works</Text>
        <Text style={styles.infoText}>• Journeys never expire</Text>
        <Text style={styles.infoText}>• Each journey includes 1 free transfer (2 hours)</Text>
        <Text style={styles.infoText}>• Valid on all Golden Arrow routes</Text>
      </View>

      <TouchableOpacity 
        style={[styles.buyButton, loading && styles.buyButtonDisabled]} 
        onPress={handlePurchase}
        disabled={loading}
      >
        <Text style={styles.buyButtonText}>
          {loading ? 'Processing...' : `Buy ${packages.find(p => p.id === selected)?.name}`}
        </Text>
      </TouchableOpacity>

      <View style={{ height: 20 }} />
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#f5f5f5' },
  header: { backgroundColor: '#FFA500', paddingVertical: 20, paddingHorizontal: 15 },
  title: { fontSize: 20, fontWeight: 'bold', color: '#fff' },
  subtitle: { fontSize: 12, color: '#ffe6cc', marginTop: 5 },
  currentBalance: { backgroundColor: '#fff', margin: 15, padding: 15, borderRadius: 8, alignItems: 'center' },
  balanceLabel: { fontSize: 12, color: '#666', marginBottom: 5 },
  balanceValue: { fontSize: 24, fontWeight: 'bold', color: '#FFA500' },
  section: { paddingHorizontal: 15, marginTop: 15 },
  label: { fontSize: 14, fontWeight: '600', color: '#333', marginBottom: 10 },
  picker: { gap: 8 },
  locationOption: { backgroundColor: '#fff', padding: 12, borderRadius: 8, borderWidth: 2, borderColor: '#ddd' },
  locationOptionActive: { borderColor: '#FFA500', backgroundColor: '#fff8f0' },
  locationText: { fontSize: 14, color: '#666' },
  locationTextActive: { color: '#FFA500', fontWeight: '600' },
  package: { backgroundColor: '#fff', marginHorizontal: 15, marginBottom: 12, padding: 16, borderRadius: 12, borderWidth: 2, borderColor: '#ddd' },
  packageSelected: { borderColor: '#FFA500', backgroundColor: '#fff8f0' },
  packageName: { fontSize: 16, fontWeight: 'bold', color: '#333', marginBottom: 5 },
  packageJourneys: { fontSize: 14, color: '#666', marginBottom: 8 },
  packagePrice: { fontSize: 24, fontWeight: 'bold', color: '#FFA500', marginBottom: 4 },
  packagePer: { fontSize: 12, color: '#999' },
  infoBox: { backgroundColor: '#e6f7ff', margin: 15, padding: 15, borderRadius: 8 },
  infoTitle: { fontSize: 14, fontWeight: '600', color: '#0066CC', marginBottom: 8 },
  infoText: { fontSize: 12, color: '#666', marginBottom: 4 },
  buyButton: { backgroundColor: '#FFA500', marginHorizontal: 15, marginBottom: 20, paddingVertical: 14, borderRadius: 8, alignItems: 'center' },
  buyButtonDisabled: { opacity: 0.6 },
  buyButtonText: { color: '#fff', fontSize: 16, fontWeight: '600' },
});
