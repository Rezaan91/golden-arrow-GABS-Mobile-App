import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  FlatList,
} from 'react-native';

export default function TransactionHistoryScreen() {
  const [filterType, setFilterType] = useState('all');

  const transactions = [
    { id: 1, date: 'Nov 25, 2024', time: '14:32', type: 'Bus Fare', amount: -15.50, operator: 'Golden Arrow' },
    { id: 2, date: 'Nov 25, 2024', time: '08:45', type: 'Train Fare', amount: -8.50, operator: 'MyCiTi' },
    { id: 3, date: 'Nov 24, 2024', time: '15:20', type: 'Top Up', amount: 100.00, operator: 'SnapScan' },
    { id: 4, date: 'Nov 24, 2024', time: '09:15', type: 'Bus Fare', amount: -15.50, operator: 'Golden Arrow' },
    { id: 5, date: 'Nov 23, 2024', time: '17:40', type: 'Bus Fare', amount: -15.50, operator: 'Golden Arrow' },
    { id: 6, date: 'Nov 23, 2024', time: '09:20', type: 'Train Fare', amount: -8.50, operator: 'MyCiTi' },
    { id: 7, date: 'Nov 22, 2024', time: '18:30', type: 'Top Up', amount: 200.00, operator: 'Zapper' },
    { id: 8, date: 'Nov 22, 2024', time: '08:50', type: 'Bus Fare', amount: -15.50, operator: 'Golden Arrow' },
  ];

  const filteredTransactions = filterType === 'all'
    ? transactions
    : transactions.filter(tx => tx.type === filterType);

  const renderTransaction = ({ item }) => (
    <View style={styles.transaction}>
      <View style={[styles.icon, item.amount > 0 ? styles.iconCredit : styles.iconDebit]}>
        <Text style={styles.iconText}>{item.amount > 0 ? '+' : '-'}</Text>
      </View>
      <View style={styles.transactionDetails}>
        <Text style={styles.transactionType}>{item.type}</Text>
        <Text style={styles.transactionSubtext}>{item.date} • {item.time}</Text>
      </View>
      <Text style={[styles.amount, item.amount > 0 ? styles.credit : styles.debit]}>
        {item.amount > 0 ? '+' : '-'}R {Math.abs(item.amount).toFixed(2)}
      </Text>
    </View>
  );

  return (
    <ScrollView style={styles.container}>
      <View style={styles.filterSection}>
        <Text style={styles.filterTitle}>Filter</Text>
        <View style={styles.filterButtons}>
          {['all', 'Bus Fare', 'Train Fare', 'Top Up'].map(filter => (
            <TouchableOpacity
              key={filter}
              style={[styles.filterButton, filterType === filter && styles.filterButtonActive]}
              onPress={() => setFilterType(filter)}
            >
              <Text style={[styles.filterButtonText, filterType === filter && styles.filterButtonTextActive]}>
                {filter === 'all' ? 'All' : filter}
              </Text>
            </TouchableOpacity>
          ))}
        </View>
      </View>

      <View style={styles.summary}>
        <View style={styles.summaryItem}>
          <Text style={styles.summaryLabel}>Total Spent</Text>
          <Text style={styles.summaryValue}>R 69.00</Text>
        </View>
        <View style={styles.summaryItem}>
          <Text style={styles.summaryLabel}>Top Ups</Text>
          <Text style={styles.summaryValue}>R 300.00</Text>
        </View>
        <View style={styles.summaryItem}>
          <Text style={styles.summaryLabel}>This Month</Text>
          <Text style={styles.summaryValue}>R 231.00</Text>
        </View>
      </View>

      <View style={styles.listContainer}>
        <FlatList
          data={filteredTransactions}
          renderItem={renderTransaction}
          keyExtractor={item => item.id.toString()}
          scrollEnabled={false}
        />
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5',
  },
  filterSection: {
    padding: 15,
    backgroundColor: '#fff',
  },
  filterTitle: {
    fontSize: 14,
    fontWeight: '600',
    color: '#333',
    marginBottom: 12,
  },
  filterButtons: {
    flexDirection: 'row',
    gap: 8,
    flexWrap: 'wrap',
  },
  filterButton: {
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderWidth: 1,
    borderColor: '#ddd',
    borderRadius: 6,
    backgroundColor: '#fff',
  },
  filterButtonActive: {
    borderColor: '#0066CC',
    backgroundColor: '#e6f2ff',
  },
  filterButtonText: {
    fontSize: 12,
    fontWeight: '500',
    color: '#666',
  },
  filterButtonTextActive: {
    color: '#0066CC',
  },
  summary: {
    flexDirection: 'row',
    marginHorizontal: 15,
    marginVertical: 15,
    gap: 10,
  },
  summaryItem: {
    flex: 1,
    backgroundColor: '#fff',
    padding: 12,
    borderRadius: 8,
    elevation: 2,
    alignItems: 'center',
  },
  summaryLabel: {
    fontSize: 12,
    color: '#666',
    marginBottom: 5,
  },
  summaryValue: {
    fontSize: 16,
    fontWeight: '700',
    color: '#333',
  },
  listContainer: {
    backgroundColor: '#fff',
    marginHorizontal: 15,
    marginBottom: 15,
    borderRadius: 8,
    elevation: 2,
    overflow: 'hidden',
  },
  transaction: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 15,
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#f0f0f0',
  },
  icon: {
    width: 40,
    height: 40,
    borderRadius: 20,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 12,
  },
  iconCredit: {
    backgroundColor: '#e6ffe6',
  },
  iconDebit: {
    backgroundColor: '#ffe6e6',
  },
  iconText: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#333',
  },
  transactionDetails: {
    flex: 1,
  },
  transactionType: {
    fontSize: 14,
    fontWeight: '600',
    color: '#333',
  },
  transactionSubtext: {
    fontSize: 12,
    color: '#999',
    marginTop: 2,
  },
  amount: {
    fontSize: 14,
    fontWeight: '700',
  },
  credit: {
    color: '#00cc00',
  },
  debit: {
    color: '#cc0000',
  },
});
