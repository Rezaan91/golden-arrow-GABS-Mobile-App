import React, { useState, useEffect, useContext } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, Alert } from 'react-native';
import { BarCodeScanner } from 'expo-barcode-scanner';
import { Ionicons } from '@expo/vector-icons';
import { WalletContext } from '../../context/WalletContext';

export default function QRScannerScreen({ navigation }) {
  const { walletState, setWalletState } = useContext(WalletContext);
  const [hasPermission, setHasPermission] = useState(null);
  const [scanned, setScanned] = useState(false);

  useEffect(() => {
    requestCameraPermission();
  }, []);

  const requestCameraPermission = async () => {
    const { status } = await BarCodeScanner.requestPermissionsAsync();
    setHasPermission(status === 'granted');
  };

  const handleBarCodeScanned = ({ data }) => {
    if (scanned) return;
    setScanned(true);

    if (!data.startsWith('GOLDEN_ARROW_BUS_')) {
      Alert.alert('Invalid QR', 'Not a Golden Arrow bus QR code');
      setTimeout(() => setScanned(false), 2000);
      return;
    }

    if (walletState.journeysRemaining <= 0) {
      Alert.alert('No Journeys', 'Buy journeys first', [
        { text: 'Buy', onPress: () => navigation.navigate('BuyJourneys') },
        { text: 'Cancel', onPress: () => setScanned(false) }
      ]);
      return;
    }

    const busId = data.replace('GOLDEN_ARROW_BUS_', '');
    const newBalance = walletState.journeysRemaining - 1;
    
    setWalletState(prev => ({
      ...prev,
      journeysRemaining: newBalance,
      transferActive: true,
      transferExpiry: Date.now() + 7200000,
      history: [
        {
          id: Date.now().toString(),
          type: 'journey',
          description: `Journey used on Bus ${busId}`,
          route: `Bus ${busId}`,
          date: new Date().toISOString(),
          journeysRemaining: newBalance,
          syncStatus: 'synced'
        },
        ...prev.history
      ]
    }));

    Alert.alert(
      '✅ Journey Activated',
      `Bus ${busId}\n${newBalance} journeys left\n2-hour transfer active`,
      [{ text: 'OK', onPress: () => navigation.goBack() }]
    );
  };

  if (hasPermission === null) {
    return (
      <View style={styles.container}>
        <Text style={styles.message}>Requesting camera permission...</Text>
      </View>
    );
  }

  if (hasPermission === false) {
    return (
      <View style={styles.container}>
        <Ionicons name="camera-off" size={64} color="rgba(255,255,255,0.3)" />
        <Text style={styles.message}>Camera permission denied</Text>
        <TouchableOpacity style={styles.button} onPress={requestCameraPermission}>
          <Text style={styles.buttonText}>Grant Permission</Text>
        </TouchableOpacity>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()} style={styles.backButton}>
          <Ionicons name="close" size={28} color="#fff" />
        </TouchableOpacity>
        <Text style={styles.title}>Scan Bus QR Code</Text>
      </View>

      <BarCodeScanner
        onBarCodeScanned={scanned ? undefined : handleBarCodeScanned}
        style={StyleSheet.absoluteFillObject}
      />

      <View style={styles.overlay}>
        <View style={styles.scanArea}>
          <View style={[styles.corner, styles.topLeft]} />
          <View style={[styles.corner, styles.topRight]} />
          <View style={[styles.corner, styles.bottomLeft]} />
          <View style={[styles.corner, styles.bottomRight]} />
        </View>
      </View>

      <View style={styles.footer}>
        <View style={styles.infoCard}>
          <Ionicons name="information-circle" size={24} color="#667eea" />
          <Text style={styles.infoText}>Point camera at bus QR code</Text>
        </View>
        <View style={styles.balanceCard}>
          <Text style={styles.balanceLabel}>Available Journeys</Text>
          <Text style={styles.balanceValue}>{walletState.journeysRemaining}</Text>
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#000', justifyContent: 'center', alignItems: 'center' },
  header: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    zIndex: 10,
    flexDirection: 'row',
    alignItems: 'center',
    paddingTop: 50,
    paddingHorizontal: 20,
    paddingBottom: 20,
    backgroundColor: 'rgba(0,0,0,0.5)',
  },
  backButton: { marginRight: 15 },
  title: { fontSize: 20, fontWeight: '700', color: '#fff' },
  overlay: { ...StyleSheet.absoluteFillObject, justifyContent: 'center', alignItems: 'center' },
  scanArea: { width: 250, height: 250, position: 'relative' },
  corner: { position: 'absolute', width: 40, height: 40, borderColor: '#f5576c', borderWidth: 4 },
  topLeft: { top: 0, left: 0, borderRightWidth: 0, borderBottomWidth: 0 },
  topRight: { top: 0, right: 0, borderLeftWidth: 0, borderBottomWidth: 0 },
  bottomLeft: { bottom: 0, left: 0, borderRightWidth: 0, borderTopWidth: 0 },
  bottomRight: { bottom: 0, right: 0, borderLeftWidth: 0, borderTopWidth: 0 },
  footer: { position: 'absolute', bottom: 0, left: 0, right: 0, padding: 20, paddingBottom: 40 },
  infoCard: { flexDirection: 'row', alignItems: 'center', gap: 12, backgroundColor: 'rgba(102, 126, 234, 0.2)', padding: 15, borderRadius: 12, marginBottom: 15 },
  infoText: { flex: 1, fontSize: 13, color: '#fff' },
  balanceCard: { backgroundColor: 'rgba(245, 87, 108, 0.2)', padding: 15, borderRadius: 12, alignItems: 'center' },
  balanceLabel: { fontSize: 12, color: 'rgba(255,255,255,0.7)', marginBottom: 5 },
  balanceValue: { fontSize: 32, fontWeight: '900', color: '#fff' },
  message: { fontSize: 16, color: '#fff', textAlign: 'center' },
  button: { backgroundColor: '#667eea', paddingHorizontal: 30, paddingVertical: 15, borderRadius: 12, marginTop: 20 },
  buttonText: { fontSize: 16, fontWeight: '700', color: '#fff' },
});
