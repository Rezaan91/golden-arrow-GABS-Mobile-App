import React, { useState, useEffect, useContext } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, Alert } from 'react-native';
import { WalletContext } from '../../context/WalletContext';
import { Ionicons } from '@expo/vector-icons';
import AsyncStorage from '@react-native-async-storage/async-storage';

export default function WalletScreen({ navigation }) {
  const { walletState, setWalletState } = useContext(WalletContext);
  const [cardLinked, setCardLinked] = useState(false);
  const [timeRemaining, setTimeRemaining] = useState('');

  useEffect(() => {
    checkCardStatus();
  }, []);

  const checkCardStatus = async () => {
    try {
      const card = await AsyncStorage.getItem('linkedCard');
      setCardLinked(!!card);
    } catch (error) {
      console.log('Check card error:', error);
    }
  };

  useEffect(() => {
    if (!walletState.transferActive) return;
    
    const timer = setInterval(() => {
      const diff = walletState.transferExpiry - Date.now();
      if (diff <= 0) {
        setWalletState(prev => ({ ...prev, transferActive: false }));
        setTimeRemaining('Expired');
      } else {
        const hours = Math.floor(diff / 3600000);
        const mins = Math.floor((diff % 3600000) / 60000);
        const secs = Math.floor((diff % 60000) / 1000);
        setTimeRemaining(`${hours}h ${mins}m ${secs}s`);
      }
    }, 1000);

    return () => clearInterval(timer);
  }, [walletState.transferActive, walletState.transferExpiry]);

  if (!cardLinked) {
    return (
      <ScrollView style={styles.container}>
        <View style={styles.header}>
          <Text style={styles.title}>My Journeys</Text>
        </View>

        <View style={styles.emptyState}>
          <Ionicons name="card" size={80} color="rgba(255,255,255,0.2)" />
          <Text style={styles.emptyTitle}>No Card Linked</Text>
          <Text style={styles.emptyText}>Link your Golden Arrow Travel Card to get started</Text>
          <TouchableOpacity
            style={styles.linkButton}
            onPress={() => navigation.navigate('Profile')}
          >
            <Ionicons name="add-circle" size={20} color="#fff" />
            <Text style={styles.linkButtonText}>Link Card Now</Text>
          </TouchableOpacity>
        </View>
      </ScrollView>
    );
  }

  return (
    <ScrollView style={styles.container}>
      {walletState.journeysRemaining <= 3 && (
        <View style={styles.alertBox}>
          <Text style={styles.alertIcon}>⚠️</Text>
          <View style={styles.alertContent}>
            <Text style={styles.alertTitle}>Low Balance Alert</Text>
            <Text style={styles.alertText}>
              You have {walletState.journeysRemaining} journey{walletState.journeysRemaining !== 1 ? 's' : ''} left. Top up soon!
            </Text>
          </View>
        </View>
      )}

      <View style={styles.card}>
        <Text style={styles.cardLabel}>GOLDEN ARROW CARD</Text>
        <Text style={styles.journeys}>{walletState.journeysRemaining}</Text>
        <Text style={styles.journeysLabel}>Journeys Remaining</Text>
        <View style={styles.ticketTypeBadge}>
          <Text style={styles.ticketType}>
            {walletState.ticketType === 'weekly' ? 'Weekly • 10 Journeys' : 'Monthly • 48 Journeys'}
          </Text>
        </View>
      </View>

      {walletState.transferActive && (
        <View style={styles.transferCard}>
          <View style={styles.transferHeader}>
            <View style={styles.transferIconBox}>
              <Text style={styles.transferIconText}>🎫</Text>
            </View>
            <Text style={styles.transferTitle}>Transfer Active</Text>
          </View>
          <Text style={styles.transferTimer}>{timeRemaining}</Text>
          <Text style={styles.transferNote}>1 transfer remaining • Expires in 2 hours</Text>
        </View>
      )}

      <TouchableOpacity 
        style={[styles.useJourneyButton, walletState.journeysRemaining === 0 && styles.useJourneyButtonDisabled]} 
        onPress={() => {
          if (walletState.journeysRemaining === 0) {
            Alert.alert('No Journeys', 'Please buy journeys first');
            return;
          }
          navigation.navigate('QRScanner');
        }}
        disabled={walletState.journeysRemaining === 0}
      >
        <Text style={styles.useJourneyButtonText}>📷 Scan Bus QR Code</Text>
      </TouchableOpacity>

      <View style={styles.quickActions}>
        <TouchableOpacity style={styles.actionCard} onPress={() => navigation.navigate('BuyJourneys')}>
          <Text style={styles.actionIcon}>💳</Text>
          <Text style={styles.actionLabel}>Buy Journeys</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.actionCard} onPress={() => navigation.navigate('TransferJourney')}>
          <Text style={styles.actionIcon}>📤</Text>
          <Text style={styles.actionLabel}>Transfer</Text>
        </TouchableOpacity>
      </View>

      <View style={{height: 40}} />
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#1a1a2e' },
  header: { paddingTop: 20, paddingHorizontal: 20, paddingBottom: 10 },
  title: { fontSize: 28, fontWeight: '900', color: '#fff' },
  emptyState: { alignItems: 'center', paddingVertical: 80, paddingHorizontal: 20 },
  emptyTitle: { fontSize: 20, fontWeight: '700', color: '#fff', marginTop: 20, marginBottom: 8 },
  emptyText: { fontSize: 14, color: 'rgba(255,255,255,0.6)', textAlign: 'center', marginBottom: 30 },
  linkButton: { flexDirection: 'row', alignItems: 'center', gap: 10, backgroundColor: '#667eea', paddingHorizontal: 20, paddingVertical: 14, borderRadius: 12 },
  linkButtonText: { fontSize: 14, fontWeight: '600', color: '#fff' },
  alertBox: { 
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: 12,
    margin: 20,
    marginBottom: 10,
    backgroundColor: '#ffd89b',
    borderRadius: 16,
    padding: 16,
  },
  alertIcon: { fontSize: 24 },
  alertContent: { flex: 1 },
  alertTitle: { fontSize: 14, fontWeight: '700', color: '#000', marginBottom: 4 },
  alertText: { fontSize: 12, color: '#333' },
  card: { 
    margin: 20,
    padding: 30,
    borderRadius: 24,
    backgroundColor: '#f5576c',
    boxShadow: '0 10px 20px rgba(245, 87, 108, 0.3)',
  },
  cardLabel: { 
    fontSize: 12, 
    color: 'rgba(255, 255, 255, 0.8)', 
    marginBottom: 15,
    letterSpacing: 1,
    fontWeight: '600',
  },
  journeys: { fontSize: 72, fontWeight: '900', color: '#fff', marginBottom: 10 },
  journeysLabel: { fontSize: 16, color: 'rgba(255, 255, 255, 0.9)', marginBottom: 15 },
  ticketTypeBadge: {
    backgroundColor: 'rgba(255, 255, 255, 0.2)',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 20,
    alignSelf: 'flex-start',
  },
  ticketType: { fontSize: 11, color: '#fff', fontWeight: '600' },
  transferCard: { 
    margin: 20,
    backgroundColor: '#667eea',
    borderRadius: 20,
    padding: 20,
    boxShadow: '0 8px 16px rgba(102, 126, 234, 0.3)',
  },
  transferHeader: { flexDirection: 'row', alignItems: 'center', gap: 10, marginBottom: 15 },
  transferIconBox: {
    width: 40,
    height: 40,
    backgroundColor: 'rgba(255, 255, 255, 0.2)',
    borderRadius: 12,
    alignItems: 'center',
    justifyContent: 'center',
  },
  transferIconText: { fontSize: 20 },
  transferTitle: { fontSize: 16, fontWeight: '700', color: '#fff' },
  transferTimer: { 
    fontSize: 48, 
    fontWeight: '900', 
    color: '#fff', 
    textAlign: 'center',
    marginVertical: 15,
  },
  transferNote: { fontSize: 12, color: 'rgba(255, 255, 255, 0.7)', textAlign: 'center' },
  useJourneyButton: { 
    backgroundColor: '#4CAF50',
    marginHorizontal: 20,
    marginTop: 20,
    paddingVertical: 18,
    borderRadius: 16,
    alignItems: 'center',
  },
  useJourneyButtonDisabled: { opacity: 0.5 },
  useJourneyButtonText: { color: '#fff', fontSize: 18, fontWeight: '700' },
  quickActions: {
    flexDirection: 'row',
    gap: 12,
    paddingHorizontal: 20,
    marginTop: 20,
  },
  actionCard: {
    flex: 1,
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.2)',
    borderRadius: 16,
    padding: 20,
    alignItems: 'center',
  },
  actionIcon: { fontSize: 32, marginBottom: 8 },
  actionLabel: { fontSize: 13, fontWeight: '600', color: '#fff' },
});
