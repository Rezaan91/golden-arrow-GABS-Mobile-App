import React, { useState, useEffect, useContext } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, Modal } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { WalletContext } from '../../context/WalletContext';

const FILTERS = ['All', 'Journeys', 'Transfers'];
const DATE_RANGES = ['Last 7 days', '30 days'];

export default function JourneyHistoryScreen() {
  const { walletState } = useContext(WalletContext);
  const [activityLog, setActivityLog] = useState([]);
  const [filter, setFilter] = useState('All');
  const [dateRange, setDateRange] = useState('Last 7 days');
  const [selectedEntry, setSelectedEntry] = useState(null);
  const [modalVisible, setModalVisible] = useState(false);

  useEffect(() => {
    loadActivity();
  }, [walletState.history]);

  const loadActivity = async () => {
    try {
      const stored = await AsyncStorage.getItem('activityLog');
      const log = stored ? JSON.parse(stored) : [];
      const merged = [...walletState.history, ...log];
      const unique = Array.from(new Map(merged.map(item => [item.id || item.date, item])).values());
      setActivityLog(unique.sort((a, b) => new Date(b.date || b.timestamp) - new Date(a.date || a.timestamp)));
    } catch (error) {
      console.log('Load activity error:', error);
    }
  };

  const getRelativeTime = (timestamp) => {
    const now = new Date();
    const then = new Date(timestamp);
    const diff = Math.floor((now - then) / 1000);
    if (diff < 60) return 'Just now';
    if (diff < 3600) return `${Math.floor(diff / 60)}m ago`;
    if (diff < 86400) return `${Math.floor(diff / 3600)}h ago`;
    return `${Math.floor(diff / 86400)}d ago`;
  };

  const filterData = () => {
    const days = dateRange === 'Last 7 days' ? 7 : 30;
    const cutoff = new Date(Date.now() - days * 86400000);
    let filtered = activityLog.filter(item => new Date(item.date || item.timestamp) > cutoff);
    if (filter === 'Journeys') filtered = filtered.filter(item => item.type === 'journey');
    if (filter === 'Transfers') filtered = filtered.filter(item => item.type === 'transfer');
    return filtered;
  };

  const getWeeklySummary = () => {
    const week = activityLog.filter(item => new Date(item.date || item.timestamp) > new Date(Date.now() - 7 * 86400000));
    const journeys = week.filter(item => item.type === 'journey').length;
    const transfers = week.filter(item => item.type === 'transfer').length;
    return { journeys, transfers, netChange: journeys + transfers };
  };

  const summary = getWeeklySummary();
  const filtered = filterData();

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.title}>Activity</Text>
        <Text style={styles.subtitle}>Your journey history</Text>
      </View>

      <View style={styles.summaryStrip}>
        <View style={styles.summaryCard}>
          <Text style={styles.summaryNumber}>{summary.journeys}</Text>
          <Text style={styles.summaryLabel}>Journeys</Text>
        </View>
        <View style={styles.summaryCard}>
          <Text style={styles.summaryNumber}>{summary.transfers}</Text>
          <Text style={styles.summaryLabel}>Transfers</Text>
        </View>
        <View style={styles.summaryCard}>
          <Text style={styles.summaryNumber}>{walletState.journeysRemaining}</Text>
          <Text style={styles.summaryLabel}>Remaining</Text>
        </View>
      </View>

      <View style={styles.filterSection}>
        <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.filterScroll}>
          {FILTERS.map((f) => (
            <TouchableOpacity
              key={f}
              style={[styles.filterChip, filter === f && styles.filterChipActive]}
              onPress={() => setFilter(f)}
            >
              <Text style={[styles.filterText, filter === f && styles.filterTextActive]}>{f}</Text>
            </TouchableOpacity>
          ))}
        </ScrollView>
        <TouchableOpacity style={styles.dateRangeBtn} onPress={() => setDateRange(dateRange === 'Last 7 days' ? '30 days' : 'Last 7 days')}>
          <Text style={styles.dateRangeText}>{dateRange}</Text>
          <Ionicons name="chevron-down" size={16} color="rgba(255,255,255,0.7)" />
        </TouchableOpacity>
      </View>

      <ScrollView style={styles.timeline}>
        {filtered.length === 0 ? (
          <View style={styles.emptyState}>
            <Ionicons name="receipt-outline" size={64} color="rgba(255,255,255,0.2)" />
            <Text style={styles.emptyTitle}>No activity yet</Text>
            <Text style={styles.emptyText}>Use your first journey to see it here</Text>
          </View>
        ) : (
          filtered.map((item, idx) => (
            <TouchableOpacity
              key={idx}
              style={styles.activityCard}
              onPress={() => {
                setSelectedEntry(item);
                setModalVisible(true);
              }}
            >
              <View style={[styles.iconBox, item.type === 'journey' ? styles.iconJourney : styles.iconTransfer]}>
                <Ionicons name={item.type === 'journey' ? 'ticket' : 'swap-horizontal'} size={24} color="#fff" />
              </View>
              <View style={styles.activityContent}>
                <Text style={styles.activityTitle}>
                  {item.type === 'journey' ? 'Journey Used' : 'Transfer Sent'}
                </Text>
                <Text style={styles.activityDesc}>
                  {item.description || (item.route ? `Route: ${item.route}` : 'Golden Arrow Bus')}
                </Text>
                <Text style={styles.activityTime}>{getRelativeTime(item.date || item.timestamp)}</Text>
              </View>
              <View style={styles.activityRight}>
                <Text style={styles.activityBalance}>{item.journeysRemaining || walletState.journeysRemaining}</Text>
                <Text style={styles.activityBalanceLabel}>left</Text>
                {item.syncStatus === 'pending' && (
                  <View style={styles.syncBadge}>
                    <Text style={styles.syncBadgeText}>Pending</Text>
                  </View>
                )}
              </View>
            </TouchableOpacity>
          ))
        )}
      </ScrollView>

      <Modal visible={modalVisible} transparent animationType="slide" onRequestClose={() => setModalVisible(false)}>
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>
                {selectedEntry?.type === 'journey' ? '🎫 Journey Details' : '↔️ Transfer Details'}
              </Text>
              <TouchableOpacity onPress={() => setModalVisible(false)}>
                <Ionicons name="close" size={28} color="#fff" />
              </TouchableOpacity>
            </View>
            {selectedEntry && (
              <View style={styles.modalBody}>
                <View style={styles.modalRow}>
                  <Text style={styles.modalLabel}>Type</Text>
                  <Text style={styles.modalValue}>{selectedEntry.type === 'journey' ? 'Journey' : 'Transfer'}</Text>
                </View>
                <View style={styles.modalRow}>
                  <Text style={styles.modalLabel}>Date</Text>
                  <Text style={styles.modalValue}>{new Date(selectedEntry.date || selectedEntry.timestamp).toLocaleString()}</Text>
                </View>
                <View style={styles.modalRow}>
                  <Text style={styles.modalLabel}>Description</Text>
                  <Text style={styles.modalValue}>{selectedEntry.description || selectedEntry.route || 'N/A'}</Text>
                </View>
                <View style={styles.modalRow}>
                  <Text style={styles.modalLabel}>Journeys Remaining</Text>
                  <Text style={styles.modalValue}>{selectedEntry.journeysRemaining || walletState.journeysRemaining}</Text>
                </View>
                {selectedEntry.transfer && (
                  <>
                    <View style={styles.modalRow}>
                      <Text style={styles.modalLabel}>Recipient</Text>
                      <Text style={styles.modalValue}>{selectedEntry.transfer.recipient}</Text>
                    </View>
                    <View style={styles.modalRow}>
                      <Text style={styles.modalLabel}>Quantity</Text>
                      <Text style={styles.modalValue}>{selectedEntry.transfer.quantity}</Text>
                    </View>
                  </>
                )}
                <View style={styles.modalRow}>
                  <Text style={styles.modalLabel}>Status</Text>
                  <View style={[styles.statusBadge, selectedEntry.syncStatus === 'synced' ? styles.statusSynced : styles.statusPending]}>
                    <Text style={styles.statusText}>{selectedEntry.syncStatus === 'synced' ? 'Synced' : 'Pending Sync'}</Text>
                  </View>
                </View>
              </View>
            )}
          </View>
        </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#1a1a2e' },
  header: { backgroundColor: '#f5576c', paddingVertical: 30, paddingHorizontal: 20, paddingTop: 50 },
  title: { fontSize: 28, fontWeight: '900', color: '#fff', marginBottom: 5 },
  subtitle: { fontSize: 14, color: 'rgba(255,255,255,0.8)' },
  summaryStrip: { flexDirection: 'row', padding: 20, gap: 12 },
  summaryCard: { flex: 1, backgroundColor: 'rgba(255,255,255,0.1)', borderRadius: 16, padding: 16, alignItems: 'center' },
  summaryNumber: { fontSize: 32, fontWeight: '900', color: '#fff', marginBottom: 4 },
  summaryLabel: { fontSize: 12, color: 'rgba(255,255,255,0.7)' },
  filterSection: { flexDirection: 'row', paddingHorizontal: 20, marginBottom: 15, alignItems: 'center', gap: 10 },
  filterScroll: { flex: 1 },
  filterChip: { backgroundColor: 'rgba(255,255,255,0.1)', paddingHorizontal: 16, paddingVertical: 8, borderRadius: 20, marginRight: 8 },
  filterChipActive: { backgroundColor: '#667eea' },
  filterText: { fontSize: 13, fontWeight: '600', color: 'rgba(255,255,255,0.7)' },
  filterTextActive: { color: '#fff' },
  dateRangeBtn: { flexDirection: 'row', alignItems: 'center', backgroundColor: 'rgba(255,255,255,0.1)', paddingHorizontal: 12, paddingVertical: 8, borderRadius: 20, gap: 4 },
  dateRangeText: { fontSize: 12, fontWeight: '600', color: 'rgba(255,255,255,0.7)' },
  timeline: { flex: 1, paddingHorizontal: 20 },
  activityCard: { flexDirection: 'row', backgroundColor: 'rgba(255,255,255,0.1)', borderRadius: 16, padding: 16, marginBottom: 12, alignItems: 'center' },
  iconBox: { width: 48, height: 48, borderRadius: 12, alignItems: 'center', justifyContent: 'center', marginRight: 15 },
  iconJourney: { backgroundColor: '#4CAF50' },
  iconTransfer: { backgroundColor: '#667eea' },
  activityContent: { flex: 1 },
  activityTitle: { fontSize: 16, fontWeight: '700', color: '#fff', marginBottom: 4 },
  activityDesc: { fontSize: 13, color: 'rgba(255,255,255,0.7)', marginBottom: 4 },
  activityTime: { fontSize: 11, color: 'rgba(255,255,255,0.5)' },
  activityRight: { alignItems: 'flex-end' },
  activityBalance: { fontSize: 24, fontWeight: '900', color: '#fff' },
  activityBalanceLabel: { fontSize: 11, color: 'rgba(255,255,255,0.5)' },
  syncBadge: { backgroundColor: '#FFA500', paddingHorizontal: 8, paddingVertical: 4, borderRadius: 12, marginTop: 4 },
  syncBadgeText: { fontSize: 10, fontWeight: '700', color: '#fff' },
  emptyState: { alignItems: 'center', paddingVertical: 60 },
  emptyTitle: { fontSize: 18, fontWeight: '700', color: '#fff', marginTop: 20, marginBottom: 8 },
  emptyText: { fontSize: 14, color: 'rgba(255,255,255,0.6)' },
  modalOverlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.8)', justifyContent: 'flex-end' },
  modalContent: { backgroundColor: '#1a1a2e', borderTopLeftRadius: 24, borderTopRightRadius: 24, paddingBottom: 40 },
  modalHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', padding: 20, borderBottomWidth: 1, borderBottomColor: 'rgba(255,255,255,0.1)' },
  modalTitle: { fontSize: 20, fontWeight: '900', color: '#fff' },
  modalBody: { padding: 20 },
  modalRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingVertical: 12, borderBottomWidth: 1, borderBottomColor: 'rgba(255,255,255,0.05)' },
  modalLabel: { fontSize: 14, color: 'rgba(255,255,255,0.6)' },
  modalValue: { fontSize: 14, fontWeight: '600', color: '#fff', textAlign: 'right', flex: 1, marginLeft: 10 },
  statusBadge: { paddingHorizontal: 12, paddingVertical: 6, borderRadius: 12 },
  statusSynced: { backgroundColor: '#4CAF50' },
  statusPending: { backgroundColor: '#FFA500' },
  statusText: { fontSize: 12, fontWeight: '700', color: '#fff' },
});
