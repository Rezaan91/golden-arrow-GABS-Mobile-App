import React, { useState, useContext } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, Alert } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { WalletContext } from '../../context/WalletContext';

export default function QRScannerScreen({ navigation }) {
  const { walletState, setWalletState } = useContext(WalletContext);
  const [mockBusId, setMockBusId] = useState('');

  const handleSimulateQR = () => {
    if (!mockBusId) {
      Alert.alert('Enter Bus ID', 'Enter a bus ID to simulate scanning');
      return;
    }

    if (walletState.journeysRemaining <= 0) {
      Alert.alert('No Journeys', 'Please buy journeys first', [
        { text: 'Buy Now', onPress: () => navigation.navigate('BuyJourneys') },
        { text: 'Cancel' }
      ]);
      return;
    }

    setWalletState(prev => ({
      ...prev,
      journeysRemaining: prev.journeysRemaining - 1,
      transferActive: true,
      transferExpiry: Date.now() + 7200000,
      history: [
        {
          id: Date.now().toString(),
          type: 'journey',
          route: `Bus ${mockBusId}`,
          date: new Date().toISOString(),
          journeysRemaining: prev.journeysRemaining - 1,
          syncStatus: 'synced'
        },
        ...prev.history
      ]
    }));

    Alert.alert(
      '✅ Journey Activated',
      `Bus ${mockBusId}\n${walletState.journeysRemaining - 1} journeys remaining\n2-hour transfer active`,
      [{ text: 'OK', onPress: () => navigation.goBack() }]
    );
  };

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()} style={styles.backButton}>
          <Ionicons name="close" size={28} color="#fff" />
        </TouchableOpacity>
        <Text style={styles.title}>Scan Bus QR Code</Text>
      </View>

      <View style={styles.content}>
        <View style={styles.mockCameraBox}>
          <Ionicons name="camera" size={64} color="rgba(255,255,255,0.3)" />
          <Text style={styles.mockCameraText}>QR Scanner (Web Demo)</Text>
          <Text style={styles.mockCameraNote}>On mobile: Point camera at bus QR code</Text>
        </View>

        <View style={styles.simulatorSection}>
          <Text style={styles.simulatorTitle}>Demo Mode: Simulate QR Scan</Text>
          <View style={styles.inputBox}>
            <Text style={styles.inputLabel}>Enter Bus ID:</Text>
            <View style={styles.inputContainer}>
              <Text style={styles.inputPrefix}>Bus </Text>
              <Text 
                style={styles.input}
                onChangeText={setMockBusId}
                placeholder="e.g., 102"
              >
                {mockBusId}
              </Text>
            </View>
          </View>

          <TouchableOpacity style={styles.simulateButton} onPress={handleSimulateQR}>
            <Ionicons name="checkmark-circle" size={24} color="#fff" />
            <Text style={styles.simulateButtonText}>Simulate Journey</Text>
          </TouchableOpacity>
        </View>

        <View style={styles.infoCard}>
          <Ionicons name="information-circle" size={24} color="#667eea" />
          <Text style={styles.infoText}>
            On mobile: Point camera at the QR code displayed on the bus
          </Text>
        </View>

        <View style={styles.balanceCard}>
          <Text style={styles.balanceLabel}>Available Journeys</Text>
          <Text style={styles.balanceValue}>{walletState.journeysRemaining}</Text>
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#1a1a2e' },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingTop: 50,
    paddingHorizontal: 20,
    paddingBottom: 20,
    backgroundColor: 'rgba(0,0,0,0.3)',
  },
  backButton: { marginRight: 15 },
  title: { fontSize: 20, fontWeight: '700', color: '#fff' },
  content: { flex: 1, padding: 20 },
  mockCameraBox: {
    backgroundColor: '#2a2a3e',
    borderRadius: 16,
    padding: 40,
    alignItems: 'center',
    marginBottom: 30,
    borderWidth: 2,
    borderColor: 'rgba(255,255,255,0.1)',
  },
  mockCameraText: { fontSize: 18, fontWeight: '700', color: '#fff', marginTop: 15, marginBottom: 8 },
  mockCameraNote: { fontSize: 13, color: 'rgba(255,255,255,0.6)' },
  simulatorSection: {
    backgroundColor: 'rgba(102, 126, 234, 0.1)',
    borderWidth: 1,
    borderColor: 'rgba(102, 126, 234, 0.3)',
    borderRadius: 16,
    padding: 20,
    marginBottom: 20,
  },
  simulatorTitle: { fontSize: 16, fontWeight: '700', color: '#667eea', marginBottom: 15 },
  inputBox: { marginBottom: 15 },
  inputLabel: { fontSize: 13, fontWeight: '600', color: 'rgba(255,255,255,0.7)', marginBottom: 8 },
  inputContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'rgba(255,255,255,0.1)',
    borderRadius: 12,
    paddingHorizontal: 15,
    paddingVertical: 12,
  },
  inputPrefix: { fontSize: 16, fontWeight: '600', color: '#fff', marginRight: 8 },
  input: { flex: 1, fontSize: 16, color: '#fff' },
  simulateButton: {
    backgroundColor: '#667eea',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 14,
    borderRadius: 12,
    gap: 10,
  },
  simulateButtonText: { fontSize: 16, fontWeight: '700', color: '#fff' },
  infoCard: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    backgroundColor: 'rgba(102, 126, 234, 0.2)',
    padding: 15,
    borderRadius: 12,
    marginBottom: 15,
  },
  infoText: { flex: 1, fontSize: 13, color: '#fff' },
  balanceCard: {
    backgroundColor: 'rgba(245, 87, 108, 0.2)',
    padding: 20,
    borderRadius: 12,
    alignItems: 'center',
  },
  balanceLabel: { fontSize: 12, color: 'rgba(255,255,255,0.7)', marginBottom: 8 },
  balanceValue: { fontSize: 32, fontWeight: '900', color: '#fff' },
});