import React, { useState, useContext, useEffect } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, Switch, Alert, TextInput, Modal } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { AuthContext } from '../../context/AuthContext';
import AsyncStorage from '@react-native-async-storage/async-storage';

export default function SettingsScreen() {
  const { signOut } = useContext(AuthContext);
  const [userData, setUserData] = useState(null);
  const [cardLinked, setCardLinked] = useState(false);
  const [cardNumber, setCardNumber] = useState('');
  const [cardExpiry, setCardExpiry] = useState('');
  const [modalVisible, setModalVisible] = useState(false);
  const [notifications, setNotifications] = useState({
    lowBalance: true,
    serviceAlerts: true,
    transferExpiry: true,
  });

  useEffect(() => {
    loadUserData();
    checkCardStatus();
  }, []);

  const loadUserData = async () => {
    try {
      const data = await AsyncStorage.getItem('userData');
      if (data) setUserData(JSON.parse(data));
    } catch (error) {
      console.log('Load user data error:', error);
    }
  };

  const checkCardStatus = async () => {
    try {
      const card = await AsyncStorage.getItem('linkedCard');
      if (card) {
        const cardData = JSON.parse(card);
        setCardLinked(true);
        setCardNumber(cardData.number);
        setCardExpiry(cardData.expiry);
      }
    } catch (error) {
      console.log('Check card error:', error);
    }
  };

  const handleLinkCard = () => {
    if (!cardNumber || cardNumber.length !== 8) {
      Alert.alert('Error', 'Card number must be 8 digits');
      return;
    }
    if (!cardExpiry || !/^\d{2}\/\d{2}\/\d{4}$/.test(cardExpiry)) {
      Alert.alert('Error', 'Expiry must be in DD/MM/YYYY format');
      return;
    }

    AsyncStorage.setItem('linkedCard', JSON.stringify({ number: cardNumber, expiry: cardExpiry }));
    setCardLinked(true);
    setModalVisible(false);
    Alert.alert('✅ Success', 'Travel Card linked successfully!');
  };

  const handleUnlinkCard = () => {
    Alert.alert('Unlink Card', 'Remove this card?', [
      { text: 'Cancel' },
      {
        text: 'Remove',
        onPress: async () => {
          await AsyncStorage.removeItem('linkedCard');
          setCardLinked(false);
          setCardNumber('');
          setCardExpiry('');
          Alert.alert('✅ Removed', 'Card has been removed');
        }
      }
    ]);
  };

  const handleLogout = () => {
    Alert.alert('Sign Out', 'Are you sure you want to sign out?', [
      { text: 'Cancel' },
      { text: 'Sign Out', onPress: () => signOut(), style: 'destructive' },
    ]);
  };

  if (!userData) {
    return (
      <View style={styles.container}>
        <Text style={styles.loadingText}>Loading...</Text>
      </View>
    );
  }

  return (
    <ScrollView style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.title}>Profile</Text>
        <Text style={styles.subtitle}>Manage your account</Text>
      </View>

      <View style={styles.section}>
        <Text style={styles.sectionTitle}>👤 Account</Text>
        <View style={styles.card}>
          <View style={styles.row}>
            <Text style={styles.label}>Name</Text>
            <Text style={styles.value}>{userData.firstName} {userData.surname}</Text>
          </View>
          <View style={styles.row}>
            <Text style={styles.label}>Phone</Text>
            <Text style={styles.value}>{userData.phone}</Text>
          </View>
          {userData.email && (
            <View style={styles.row}>
              <Text style={styles.label}>Email</Text>
              <Text style={styles.value}>{userData.email}</Text>
            </View>
          )}
        </View>
      </View>

      <View style={styles.section}>
        <Text style={styles.sectionTitle}>💳 Travel Card</Text>
        <View style={styles.card}>
          {cardLinked ? (
            <>
              <View style={styles.cardDisplay}>
                <Ionicons name="card" size={32} color="#f5576c" />
                <View style={styles.cardInfo}>
                  <Text style={styles.cardNumber}>•••• {cardNumber.slice(-4)}</Text>
                  <Text style={styles.cardExpiry}>Expires: {cardExpiry}</Text>
                </View>
              </View>
              <TouchableOpacity style={styles.linkButton} onPress={handleUnlinkCard}>
                <Text style={styles.linkText}>Remove Card</Text>
                <Ionicons name="chevron-forward" size={16} color="#f5576c" />
              </TouchableOpacity>
            </>
          ) : (
            <TouchableOpacity style={styles.addCardButton} onPress={() => setModalVisible(true)}>
              <Ionicons name="add-circle" size={24} color="#4CAF50" />
              <Text style={styles.addCardText}>Link Your Card</Text>
            </TouchableOpacity>
          )}
        </View>
      </View>

      <View style={styles.section}>
        <Text style={styles.sectionTitle}>🔔 Notifications</Text>
        <View style={styles.card}>
          <View style={styles.switchRow}>
            <View style={styles.switchInfo}>
              <Text style={styles.switchLabel}>Low Balance Alerts</Text>
              <Text style={styles.switchDesc}>Notify when ≤3 journeys left</Text>
            </View>
            <Switch
              value={notifications.lowBalance}
              onValueChange={(val) => setNotifications({ ...notifications, lowBalance: val })}
              trackColor={{ false: '#ccc', true: '#4CAF50' }}
            />
          </View>
        </View>
      </View>

      <TouchableOpacity style={styles.logoutButton} onPress={handleLogout}>
        <Ionicons name="log-out" size={20} color="#fff" />
        <Text style={styles.logoutText}>Sign Out</Text>
      </TouchableOpacity>

      <View style={styles.footer}>
        <Text style={styles.footerText}>Golden Arrow Commuter App</Text>
      </View>

      <Modal visible={modalVisible} transparent animationType="slide" onRequestClose={() => setModalVisible(false)}>
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>Link Travel Card</Text>
              <TouchableOpacity onPress={() => setModalVisible(false)}>
                <Ionicons name="close" size={28} color="#fff" />
              </TouchableOpacity>
            </View>

            <View style={styles.modalBody}>
              <Text style={styles.modalLabel}>Card Number (8 digits)</Text>
              <TextInput
                style={styles.modalInput}
                placeholder="12345678"
                value={cardNumber}
                onChangeText={setCardNumber}
                keyboardType="number-pad"
                maxLength={8}
              />

              <Text style={styles.modalLabel}>Expiry Date (DD/MM/YYYY)</Text>
              <TextInput
                style={styles.modalInput}
                placeholder="31/12/2025"
                value={cardExpiry}
                onChangeText={setCardExpiry}
                maxLength={10}
              />

              <TouchableOpacity style={styles.modalButton} onPress={handleLinkCard}>
                <Text style={styles.modalButtonText}>Link Card</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#1a1a2e' },
  loadingText: { color: '#fff', textAlign: 'center', marginTop: 50 },
  header: { backgroundColor: '#f5576c', paddingVertical: 30, paddingHorizontal: 20, paddingTop: 50 },
  title: { fontSize: 28, fontWeight: '900', color: '#fff', marginBottom: 5 },
  subtitle: { fontSize: 14, color: 'rgba(255,255,255,0.8)' },
  section: { paddingHorizontal: 20, marginTop: 20 },
  sectionTitle: { fontSize: 16, fontWeight: '700', color: '#fff', marginBottom: 12 },
  card: { backgroundColor: 'rgba(255,255,255,0.1)', borderRadius: 16, padding: 16 },
  row: { flexDirection: 'row', justifyContent: 'space-between', paddingVertical: 12, borderBottomWidth: 1, borderBottomColor: 'rgba(255,255,255,0.05)' },
  label: { fontSize: 14, color: 'rgba(255,255,255,0.7)' },
  value: { fontSize: 14, fontWeight: '600', color: '#fff' },
  cardDisplay: { flexDirection: 'row', alignItems: 'center', gap: 15, paddingVertical: 12, borderBottomWidth: 1, borderBottomColor: 'rgba(255,255,255,0.05)' },
  cardInfo: { flex: 1 },
  cardNumber: { fontSize: 18, fontWeight: '700', color: '#fff', marginBottom: 4 },
  cardExpiry: { fontSize: 12, color: 'rgba(255,255,255,0.6)' },
  addCardButton: { flexDirection: 'row', alignItems: 'center', gap: 10, paddingVertical: 12 },
  addCardText: { fontSize: 14, fontWeight: '600', color: '#4CAF50' },
  linkButton: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingVertical: 12 },
  linkText: { fontSize: 14, fontWeight: '600', color: '#f5576c' },
  switchRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingVertical: 12 },
  switchInfo: { flex: 1, marginRight: 15 },
  switchLabel: { fontSize: 14, fontWeight: '600', color: '#fff', marginBottom: 4 },
  switchDesc: { fontSize: 12, color: 'rgba(255,255,255,0.6)' },
  logoutButton: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 10, backgroundColor: '#cc0000', marginHorizontal: 20, marginTop: 30, paddingVertical: 16, borderRadius: 16 },
  logoutText: { fontSize: 16, fontWeight: '700', color: '#fff' },
  footer: { alignItems: 'center', paddingVertical: 40 },
  footerText: { fontSize: 12, color: 'rgba(255,255,255,0.5)' },
  modalOverlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.8)', justifyContent: 'flex-end' },
  modalContent: { backgroundColor: '#1a1a2e', borderTopLeftRadius: 24, borderTopRightRadius: 24, paddingBottom: 40 },
  modalHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', padding: 20, borderBottomWidth: 1, borderBottomColor: 'rgba(255,255,255,0.1)' },
  modalTitle: { fontSize: 20, fontWeight: '900', color: '#fff' },
  modalBody: { padding: 20 },
  modalLabel: { fontSize: 14, fontWeight: '600', color: '#fff', marginBottom: 8, marginTop: 15 },
  modalInput: { backgroundColor: 'rgba(255,255,255,0.1)', borderWidth: 1, borderColor: 'rgba(255,255,255,0.2)', borderRadius: 12, paddingHorizontal: 15, paddingVertical: 12, fontSize: 14, color: '#fff', marginBottom: 15 },
  modalButton: { backgroundColor: '#667eea', paddingVertical: 16, borderRadius: 12, alignItems: 'center', marginTop: 10 },
  modalButtonText: { color: '#fff', fontSize: 16, fontWeight: '700' },
});
