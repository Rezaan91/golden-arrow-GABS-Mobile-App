import React, { useState, useContext } from 'react';
import { View, Text, StyleSheet, TextInput, TouchableOpacity, Alert } from 'react-native';
import { AuthContext } from '../../context/AuthContext';
import { WalletContext } from '../../context/WalletContext';

export default function CardLinkingScreen({ navigation }) {
  const [cardNumber, setCardNumber] = useState('');
  const [expiryMonth, setExpiryMonth] = useState('');
  const [expiryYear, setExpiryYear] = useState('');
  const [loading, setLoading] = useState(false);
  const { signIn } = useContext(AuthContext);
  const { setWalletState } = useContext(WalletContext);

  const handleLink = async () => {
    if (cardNumber.length !== 8) {
      Alert.alert('Error', 'Please enter a valid 8-digit card number');
      return;
    }
    if (expiryMonth.length !== 2 || expiryYear.length !== 2) {
      Alert.alert('Error', 'Please enter expiry date (MM/YY)');
      return;
    }
    setLoading(true);
    try {
      await new Promise(resolve => setTimeout(resolve, 1500));
      setWalletState(prev => ({ ...prev, cardNumber, cardExpiry: `${expiryMonth}/${expiryYear}` }));
      await signIn({ cardNumber });
    } catch (error) {
      Alert.alert('Error', 'Failed to link card');
    } finally {
      setLoading(false);
    }
  };

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.title}>Link Your Card</Text>
        <Text style={styles.subtitle}>Enter your Golden Arrow card number</Text>
      </View>

      <View style={styles.form}>
        <Text style={styles.label}>Card Number</Text>
        <TextInput
          style={styles.input}
          placeholder="12345678"
          value={cardNumber}
          onChangeText={setCardNumber}
          keyboardType="number-pad"
          maxLength={8}
          editable={!loading}
        />
        <Text style={styles.hint}>8-digit number on your Golden Arrow card</Text>

        <Text style={styles.label}>Expiry Date</Text>
        <View style={styles.expiryRow}>
          <TextInput
            style={[styles.input, styles.expiryInput]}
            placeholder="MM"
            value={expiryMonth}
            onChangeText={setExpiryMonth}
            keyboardType="number-pad"
            maxLength={2}
            editable={!loading}
          />
          <Text style={styles.expirySlash}>/</Text>
          <TextInput
            style={[styles.input, styles.expiryInput]}
            placeholder="YY"
            value={expiryYear}
            onChangeText={setExpiryYear}
            keyboardType="number-pad"
            maxLength={2}
            editable={!loading}
          />
        </View>
        <Text style={styles.hint}>Card expiry date (MM/YY)</Text>

        <TouchableOpacity
          style={[styles.button, loading && styles.buttonDisabled]}
          onPress={handleLink}
          disabled={loading}
        >
          <Text style={styles.buttonText}>{loading ? 'Linking...' : 'Link Card'}</Text>
        </TouchableOpacity>

        <TouchableOpacity style={styles.skipButton} onPress={() => signIn({})}>
          <Text style={styles.skipText}>Skip for now</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#f5f5f5' },
  header: { backgroundColor: '#FFA500', paddingVertical: 40, paddingHorizontal: 20 },
  title: { fontSize: 24, fontWeight: 'bold', color: '#fff', marginBottom: 5 },
  subtitle: { fontSize: 14, color: '#ffe6cc' },
  form: { padding: 20 },
  label: { fontSize: 14, fontWeight: '600', color: '#333', marginBottom: 8 },
  input: { borderWidth: 1, borderColor: '#ddd', borderRadius: 8, paddingHorizontal: 15, paddingVertical: 12, fontSize: 16, backgroundColor: '#fff', marginBottom: 8 },
  hint: { fontSize: 11, color: '#999', marginBottom: 20 },
  button: { backgroundColor: '#FFA500', paddingVertical: 14, borderRadius: 8, alignItems: 'center' },
  buttonDisabled: { opacity: 0.7 },
  buttonText: { color: '#fff', fontSize: 16, fontWeight: '600' },
  skipButton: { marginTop: 15, alignItems: 'center' },
  skipText: { color: '#FFA500', fontSize: 14, fontWeight: '600' },
  expiryRow: { flexDirection: 'row', alignItems: 'center', gap: 10 },
  expiryInput: { flex: 1 },
  expirySlash: { fontSize: 24, color: '#666', fontWeight: 'bold' },
});
