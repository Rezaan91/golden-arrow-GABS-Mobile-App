import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  FlatList,
  Switch,
} from 'react-native';

export default function NotificationsScreen({ navigation }) {
  const [notifications, setNotifications] = useState([
    {
      id: 1,
      type: 'balance',
      title: 'Low Balance Alert',
      message: 'Your balance is below R 50. Consider topping up.',
      timestamp: '2 hours ago',
      read: false,
      severity: 'warning',
    },
    {
      id: 2,
      type: 'alert',
      title: 'Strike Alert: Golden Arrow',
      message: 'Golden Arrow buses are experiencing delays due to staff meetings.',
      timestamp: '4 hours ago',
      read: false,
      severity: 'critical',
    },
    {
      id: 3,
      type: 'closure',
      title: 'Road Closure: M6 Freeway',
      message: 'The M6 freeway towards Khayelitsha is closed for maintenance from 10 PM to 6 AM.',
      timestamp: 'Yesterday',
      read: true,
      severity: 'info',
    },
    {
      id: 4,
      type: 'alert',
      title: 'MyCiTi Service Update',
      message: 'Route 102 service has resumed normal operations.',
      timestamp: '2 days ago',
      read: true,
      severity: 'info',
    },
  ]);

  const renderNotification = ({ item }) => (
    <TouchableOpacity style={[styles.notification, !item.read && styles.unread]}>
      <View style={[styles.severityBadge, styles[`severity${item.severity}`]]}>
        <Text style={styles.badgeText}>
          {item.severity === 'critical' ? '!' : item.severity === 'warning' ? '⚠' : 'ℹ'}
        </Text>
      </View>
      <View style={styles.notificationContent}>
        <Text style={styles.notificationTitle}>{item.title}</Text>
        <Text style={styles.notificationMessage}>{item.message}</Text>
        <Text style={styles.timestamp}>{item.timestamp}</Text>
      </View>
    </TouchableOpacity>
  );

  return (
    <ScrollView style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.headerTitle}>Alerts</Text>
        <TouchableOpacity onPress={() => navigation.navigate('AlertSettings')}>
          <Text style={styles.settingsLink}>⚙ Settings</Text>
        </TouchableOpacity>
      </View>

      <View style={styles.stats}>
        <View style={styles.statItem}>
          <Text style={styles.statLabel}>Critical</Text>
          <Text style={styles.statValue}>1</Text>
        </View>
        <View style={styles.statItem}>
          <Text style={styles.statLabel}>Warnings</Text>
          <Text style={styles.statValue}>1</Text>
        </View>
        <View style={styles.statItem}>
          <Text style={styles.statLabel}>Unread</Text>
          <Text style={styles.statValue}>2</Text>
        </View>
      </View>

      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Recent Alerts</Text>
        <FlatList
          data={notifications}
          renderItem={renderNotification}
          keyExtractor={item => item.id.toString()}
          scrollEnabled={false}
        />
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5',
  },
  header: {
    backgroundColor: '#FFA500',
    paddingVertical: 15,
    paddingHorizontal: 15,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  headerTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#fff',
  },
  settingsLink: {
    color: '#fff',
    fontSize: 14,
    fontWeight: '600',
  },
  stats: {
    flexDirection: 'row',
    marginHorizontal: 15,
    marginVertical: 15,
    gap: 10,
  },
  statItem: {
    flex: 1,
    backgroundColor: '#fff',
    padding: 12,
    borderRadius: 8,
    alignItems: 'center',
    elevation: 2,
  },
  statLabel: {
    fontSize: 12,
    color: '#666',
    marginBottom: 5,
  },
  statValue: {
    fontSize: 20,
    fontWeight: '700',
    color: '#FFA500',
  },
  section: {
    paddingHorizontal: 15,
    marginBottom: 20,
  },
  sectionTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: '#333',
    marginBottom: 10,
  },
  notification: {
    flexDirection: 'row',
    backgroundColor: '#fff',
    padding: 12,
    marginBottom: 10,
    borderRadius: 8,
    elevation: 2,
  },
  unread: {
    backgroundColor: '#f0f8ff',
  },
  severityBadge: {
    width: 40,
    height: 40,
    borderRadius: 20,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 12,
  },
  severityinfo: {
    backgroundColor: '#e6f2ff',
  },
  severitywarning: {
    backgroundColor: '#fff9e6',
  },
  severitycritical: {
    backgroundColor: '#ffe6e6',
  },
  badgeText: {
    fontSize: 18,
    fontWeight: 'bold',
  },
  notificationContent: {
    flex: 1,
  },
  notificationTitle: {
    fontSize: 14,
    fontWeight: '600',
    color: '#333',
    marginBottom: 4,
  },
  notificationMessage: {
    fontSize: 13,
    color: '#666',
    lineHeight: 18,
    marginBottom: 6,
  },
  timestamp: {
    fontSize: 11,
    color: '#999',
  },
});
