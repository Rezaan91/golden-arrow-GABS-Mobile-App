import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  Switch,
  TouchableOpacity,
} from 'react-native';

export default function AlertSettingsScreen() {
  const [settings, setSettings] = useState({
    lowBalance: true,
    outOfBalance: true,
    strikes: true,
    roadClosures: true,
    delayAlerts: true,
    crowdingAlerts: false,
    communityAlerts: true,
    pushNotifications: true,
    smsNotifications: true,
  });

  const toggleSetting = (key) => {
    setSettings(prev => ({ ...prev, [key]: !prev[key] }));
  };

  const SettingRow = ({ label, description, value, onToggle }) => (
    <View style={styles.settingRow}>
      <View style={styles.settingContent}>
        <Text style={styles.settingLabel}>{label}</Text>
        <Text style={styles.settingDescription}>{description}</Text>
      </View>
      <Switch value={value} onValueChange={onToggle} />
    </View>
  );

  return (
    <ScrollView style={styles.container}>
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Balance Alerts</Text>
        <SettingRow
          label="Low Balance Alert"
          description="Notify when balance < R 50"
          value={settings.lowBalance}
          onToggle={() => toggleSetting('lowBalance')}
        />
        <SettingRow
          label="Out of Balance Alert"
          description="Notify when balance = R 0"
          value={settings.outOfBalance}
          onToggle={() => toggleSetting('outOfBalance')}
        />
      </View>

      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Service Disruption Alerts</Text>
        <SettingRow
          label="Strikes & Suspensions"
          description="Notify about labor actions and service suspensions"
          value={settings.strikes}
          onToggle={() => toggleSetting('strikes')}
        />
        <SettingRow
          label="Road Closures"
          description="Notify about planned road closures & maintenance"
          value={settings.roadClosures}
          onToggle={() => toggleSetting('roadClosures')}
        />
        <SettingRow
          label="Delay Alerts"
          description="Notify about unexpected delays and traffic"
          value={settings.delayAlerts}
          onToggle={() => toggleSetting('delayAlerts')}
        />
      </View>

      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Community Alerts</Text>
        <SettingRow
          label="Crowding Alerts"
          description="Notify about overcrowded buses and trains"
          value={settings.crowdingAlerts}
          onToggle={() => toggleSetting('crowdingAlerts')}
        />
        <SettingRow
          label="Group Updates"
          description="Notify about community group messages"
          value={settings.communityAlerts}
          onToggle={() => toggleSetting('communityAlerts')}
        />
      </View>

      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Notification Channels</Text>
        <SettingRow
          label="Push Notifications"
          description="Receive in-app and push notifications"
          value={settings.pushNotifications}
          onToggle={() => toggleSetting('pushNotifications')}
        />
        <SettingRow
          label="SMS Notifications"
          description="Receive critical alerts via SMS (may incur charges)"
          value={settings.smsNotifications}
          onToggle={() => toggleSetting('smsNotifications')}
        />
      </View>

      <View style={styles.infoBox}>
        <Text style={styles.infoTitle}>📱 About Notifications</Text>
        <Text style={styles.infoText}>
          Critical alerts (strikes, road closures, out-of-balance) will be sent even if you disable certain notification types. SMS notifications are limited to urgent alerts only.
        </Text>
      </View>

      <TouchableOpacity style={styles.resetButton}>
        <Text style={styles.resetButtonText}>Reset to Defaults</Text>
      </TouchableOpacity>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5',
  },
  section: {
    backgroundColor: '#fff',
    marginVertical: 10,
  },
  sectionTitle: {
    fontSize: 14,
    fontWeight: '600',
    color: '#0066CC',
    paddingHorizontal: 15,
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#eee',
  },
  settingRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 15,
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#f0f0f0',
  },
  settingContent: {
    flex: 1,
  },
  settingLabel: {
    fontSize: 14,
    fontWeight: '600',
    color: '#333',
    marginBottom: 4,
  },
  settingDescription: {
    fontSize: 12,
    color: '#999',
  },
  infoBox: {
    backgroundColor: '#e6f2ff',
    marginHorizontal: 15,
    marginVertical: 20,
    padding: 12,
    borderRadius: 8,
    borderLeftWidth: 4,
    borderLeftColor: '#0066CC',
  },
  infoTitle: {
    fontSize: 13,
    fontWeight: '600',
    color: '#0066CC',
    marginBottom: 6,
  },
  infoText: {
    fontSize: 12,
    color: '#0066CC',
    lineHeight: 16,
  },
  resetButton: {
    marginHorizontal: 15,
    marginBottom: 20,
    paddingVertical: 12,
    borderWidth: 2,
    borderColor: '#ddd',
    borderRadius: 8,
    alignItems: 'center',
  },
  resetButtonText: {
    fontSize: 14,
    fontWeight: '600',
    color: '#666',
  },
});
