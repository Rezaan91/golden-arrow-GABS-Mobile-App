import React, { useState } from 'react';
import { View, Text, StyleSheet, TextInput, TouchableOpacity, ScrollView, Alert, Dimensions } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import goldenArrowRoutes from '../../data/goldenArrowRoutes.json';

const POPULAR_DESTINATIONS = [
  'City Centre', 'Bellville', 'Wynberg', 'Claremont', 'Durbanville',
  'Blaauwberg', 'Century City', 'Strand', 'Somerset West', 'Malmesbury', 'Atlantis'
];

export default function RouteFinderScreen() {
  const [origin, setOrigin] = useState('Cape Town CBD');
  const [destination, setDestination] = useState('');
  const [matchedRoutes, setMatchedRoutes] = useState([]);
  const [loading, setLoading] = useState(false);

  const findRoute = () => {
    if (!origin || !destination) {
      Alert.alert('Missing Info', 'Please enter both origin and destination');
      return;
    }
    setLoading(true);
    setTimeout(() => {
      const matched = goldenArrowRoutes.filter(route => {
        const originMatch = origin.toLowerCase().includes(route.origin.toLowerCase()) ||
                           route.origin.toLowerCase().includes(origin.toLowerCase()) ||
                           route.corridorNotes.some(note => origin.toLowerCase().includes(note.toLowerCase()));
        const destMatch = destination.toLowerCase().includes(route.endPoint.toLowerCase()) ||
                         route.endPoint.toLowerCase().includes(destination.toLowerCase()) ||
                         route.corridorNotes.some(note => destination.toLowerCase().includes(note.toLowerCase()));
        return originMatch && destMatch;
      });
      
      const sorted = matched.sort((a, b) => {
        const stopsA = a.corridorNotes.length;
        const stopsB = b.corridorNotes.length;
        if (a.busLabel.includes('Express')) return -1;
        if (b.busLabel.includes('Express')) return 1;
        return stopsA - stopsB;
      });
      
      setMatchedRoutes(sorted);
      setLoading(false);
      if (sorted.length === 0) {
        Alert.alert('No Route Found', 'No direct Golden Arrow route matches your journey. Try popular destinations.');
      }
    }, 800);
  };

  const selectDestination = (dest) => {
    setDestination(dest);
    setTimeout(() => {
      if (origin) {
        setLoading(true);
        setTimeout(() => {
          const matched = goldenArrowRoutes.filter(route => {
            const originMatch = origin.toLowerCase().includes(route.origin.toLowerCase()) ||
                               route.origin.toLowerCase().includes(origin.toLowerCase());
            const destMatch = dest.toLowerCase().includes(route.endPoint.toLowerCase()) ||
                             route.endPoint.toLowerCase().includes(dest.toLowerCase());
            return originMatch && destMatch;
          });
          setMatchedRoutes(matched);
          setLoading(false);
        }, 800);
      }
    }, 100);
  };

  return (
    <ScrollView style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.title}>Find Your Route</Text>
        <Text style={styles.subtitle}>Golden Arrow Bus Services</Text>
      </View>

      <View style={styles.searchSection}>
        <View style={styles.inputContainer}>
          <Ionicons name="location" size={20} color="#f5576c" style={styles.icon} />
          <TextInput
            style={styles.input}
            placeholder="From (Your Location)"
            placeholderTextColor="rgba(255,255,255,0.5)"
            value={origin}
            onChangeText={setOrigin}
          />
        </View>

        <View style={styles.inputContainer}>
          <Ionicons name="flag" size={20} color="#4CAF50" style={styles.icon} />
          <TextInput
            style={styles.input}
            placeholder="To (Destination)"
            placeholderTextColor="rgba(255,255,255,0.5)"
            value={destination}
            onChangeText={setDestination}
          />
        </View>

        <TouchableOpacity style={styles.findButton} onPress={findRoute}>
          <Text style={styles.findButtonText}>{loading ? 'Searching...' : '🔍 Find Route'}</Text>
        </TouchableOpacity>
      </View>

      {matchedRoutes.length > 0 && (
        <View style={styles.resultsSection}>
          <Text style={styles.resultsTitle}>{matchedRoutes.length} Route{matchedRoutes.length > 1 ? 's' : ''} Found</Text>
          {matchedRoutes.map((route, index) => (
            <View key={index} style={styles.resultCard}>
              {index === 0 && (
                <View style={styles.recommendedBadge}>
                  <Text style={styles.recommendedText}>⚡ FASTEST</Text>
                </View>
              )}
              <View style={styles.resultHeader}>
                <Ionicons name="bus" size={32} color="#f5576c" />
                <View style={styles.resultHeaderText}>
                  <Text style={styles.busLabel}>{route.busLabel}</Text>
                  <Text style={styles.routeEndpoints}>{route.origin} → {route.endPoint}</Text>
                </View>
              </View>
              <View style={styles.routeStats}>
                <View style={styles.statItem}>
                  <Text style={styles.statValue}>{route.corridorNotes.length}</Text>
                  <Text style={styles.statLabel}>stops</Text>
                </View>
                <View style={styles.statItem}>
                  <Text style={styles.statValue}>{route.busLabel.includes('Express') ? 'Express' : 'Local'}</Text>
                  <Text style={styles.statLabel}>type</Text>
                </View>
              </View>
              <View style={styles.corridorSection}>
                <Text style={styles.corridorTitle}>Route Stops:</Text>
                {route.corridorNotes.map((note, idx) => (
                  <View key={idx} style={styles.stopItem}>
                    <View style={styles.stopDot} />
                    <Text style={styles.stopText}>{note}</Text>
                  </View>
                ))}
              </View>
            </View>
          ))}
        </View>
      )}

      <View style={styles.popularSection}>
        <Text style={styles.popularTitle}>Popular Destinations</Text>
        <View style={styles.popularGrid}>
          {POPULAR_DESTINATIONS.map((dest, idx) => (
            <TouchableOpacity
              key={idx}
              style={styles.popularChip}
              onPress={() => selectDestination(dest)}
            >
              <Text style={styles.popularChipText}>{dest}</Text>
            </TouchableOpacity>
          ))}
        </View>
      </View>

      <View style={{height: 40}} />
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#1a1a2e' },
  header: {
    backgroundColor: '#f5576c',
    paddingVertical: 30,
    paddingHorizontal: 20,
    paddingTop: 50,
  },
  title: { fontSize: 28, fontWeight: '900', color: '#fff', marginBottom: 5 },
  subtitle: { fontSize: 14, color: 'rgba(255,255,255,0.8)' },
  searchSection: { padding: 20 },
  inputContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'rgba(255,255,255,0.1)',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.2)',
    borderRadius: 16,
    paddingHorizontal: 15,
    paddingVertical: 12,
    marginBottom: 12,
  },
  icon: { marginRight: 10 },
  input: {
    flex: 1,
    fontSize: 16,
    color: '#fff',
  },
  findButton: {
    backgroundColor: '#667eea',
    paddingVertical: 16,
    borderRadius: 16,
    alignItems: 'center',
    marginTop: 8,
  },
  findButtonText: { fontSize: 18, fontWeight: '700', color: '#fff' },
  resultCard: {
    margin: 20,
    marginTop: 0,
    backgroundColor: 'rgba(255,255,255,0.1)',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.2)',
    borderRadius: 20,
    padding: 20,
  },
  resultHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 15,
    marginBottom: 20,
    paddingBottom: 15,
    borderBottomWidth: 1,
    borderBottomColor: 'rgba(255,255,255,0.1)',
  },
  resultHeaderText: { flex: 1 },
  busLabel: { fontSize: 20, fontWeight: '900', color: '#fff', marginBottom: 5 },
  routeEndpoints: { fontSize: 13, color: 'rgba(255,255,255,0.7)' },
  corridorSection: { marginTop: 10 },
  corridorTitle: { fontSize: 14, fontWeight: '700', color: '#667eea', marginBottom: 12 },
  stopItem: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 10,
  },
  stopDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: '#f5576c',
    marginRight: 12,
  },
  stopText: { fontSize: 13, color: 'rgba(255,255,255,0.8)' },
  popularSection: { paddingHorizontal: 20, marginTop: 10 },
  popularTitle: { fontSize: 18, fontWeight: '700', color: '#fff', marginBottom: 15 },
  popularGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 10,
  },
  popularChip: {
    backgroundColor: 'rgba(102, 126, 234, 0.2)',
    borderWidth: 1,
    borderColor: 'rgba(102, 126, 234, 0.4)',
    paddingHorizontal: 16,
    paddingVertical: 10,
    borderRadius: 20,
  },
  popularChipText: { fontSize: 13, fontWeight: '600', color: '#667eea' },
  resultsSection: { paddingHorizontal: 20, marginTop: 10 },
  resultsTitle: { fontSize: 16, fontWeight: '700', color: '#fff', marginBottom: 15 },
  recommendedBadge: {
    position: 'absolute',
    top: 15,
    right: 15,
    backgroundColor: '#4CAF50',
    paddingHorizontal: 10,
    paddingVertical: 5,
    borderRadius: 12,
    zIndex: 10,
  },
  recommendedText: { fontSize: 11, fontWeight: '900', color: '#fff' },
  routeStats: {
    flexDirection: 'row',
    gap: 20,
    paddingVertical: 15,
    borderBottomWidth: 1,
    borderBottomColor: 'rgba(255,255,255,0.1)',
  },
  statItem: { alignItems: 'center' },
  statValue: { fontSize: 18, fontWeight: '900', color: '#667eea', marginBottom: 4 },
  statLabel: { fontSize: 11, color: 'rgba(255,255,255,0.6)' },
});