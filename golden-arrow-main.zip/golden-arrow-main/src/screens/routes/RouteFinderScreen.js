import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, TextInput, TouchableOpacity, ScrollView, Alert, FlatList } from 'react-native';
import * as Location from 'expo-location';
import { Ionicons } from '@expo/vector-icons';
import MapView, { Marker } from 'react-native-maps';
import goldenArrowRoutes from '../../data/goldenArrowRoutes.json';

const POPULAR_DESTINATIONS = [
  'City Centre', 'Bellville', 'Wynberg', 'Claremont', 'Durbanville',
  'Blaauwberg', 'Century City', 'Strand', 'Somerset West', 'Malmesbury', 'Atlantis'
];

const ALL_LOCATIONS = [
  'City Centre', 'Bellville', 'Wynberg', 'Claremont', 'Durbanville',
  'Blaauwberg', 'Century City', 'Strand', 'Somerset West', 'Malmesbury', 'Atlantis',
  'Khayelitsha', 'Phillipi', 'Mitchells Plain', 'Athlone', 'Langa', 'Gugulethu',
  'Constantia', 'Camps Bay', 'Clifton', 'Muizenberg', 'Simonstown'
];

export default function RouteFinderScreen() {
  const [origin, setOrigin] = useState('');
  const [destination, setDestination] = useState('');
  const [currentLocation, setCurrentLocation] = useState(null);
  const [matchedRoutes, setMatchedRoutes] = useState([]);
  const [loading, setLoading] = useState(false);
  const [showMap, setShowMap] = useState(false);
  const [suggestions, setSuggestions] = useState([]);
  const [showSuggestions, setShowSuggestions] = useState(false);
  const [region, setRegion] = useState({
    latitude: -33.9249,
    longitude: 18.4241,
    latitudeDelta: 0.3,
    longitudeDelta: 0.3,
  });

  useEffect(() => {
    getCurrentLocation();
  }, []);

  const getCurrentLocation = async () => {
    try {
      const { status } = await Location.requestForegroundPermissionsAsync();
      if (status !== 'granted') {
        Alert.alert('Permission Denied', 'Location access required for route finding');
        return;
      }
      const location = await Location.getCurrentPositionAsync({});
      const address = await Location.reverseGeocodeAsync({
        latitude: location.coords.latitude,
        longitude: location.coords.longitude
      });
      if (address[0]) {
        const loc = `${address[0].street || ''}, ${address[0].city || address[0].region || ''}`.trim();
        setOrigin(loc);
        setCurrentLocation(loc);
      }
    } catch (error) {
      console.log('Location error:', error);
    }
  };

  const handleDestinationChange = (text) => {
    setDestination(text);
    if (text.length > 0) {
      const filtered = ALL_LOCATIONS.filter(loc =>
        loc.toLowerCase().includes(text.toLowerCase())
      );
      setSuggestions(filtered);
      setShowSuggestions(true);
    } else {
      setSuggestions([]);
      setShowSuggestions(false);
    }
  };

  const selectSuggestion = (suggestion) => {
    setDestination(suggestion);
    setShowSuggestions(false);
    setTimeout(() => findRoute(suggestion), 100);
  };

  const findRoute = (dest = destination) => {
    if (!origin || !dest) {
      Alert.alert('Missing Info', 'Please enter both origin and destination');
      return;
    }
    setLoading(true);
    setTimeout(() => {
      const matched = goldenArrowRoutes.filter(route => {
        const originMatch = origin.toLowerCase().includes(route.origin.toLowerCase()) ||
                           route.origin.toLowerCase().includes(origin.toLowerCase()) ||
                           route.corridorNotes.some(note => origin.toLowerCase().includes(note.toLowerCase()));
        const destMatch = dest.toLowerCase().includes(route.endPoint.toLowerCase()) ||
                         route.endPoint.toLowerCase().includes(dest.toLowerCase()) ||
                         route.corridorNotes.some(note => dest.toLowerCase().includes(note.toLowerCase()));
        return originMatch && destMatch;
      });
      
      const sorted = matched.sort((a, b) => {
        if (a.busLabel.includes('Express')) return -1;
        if (b.busLabel.includes('Express')) return 1;
        return a.corridorNotes.length - b.corridorNotes.length;
      });
      
      setMatchedRoutes(sorted);
      setShowMap(sorted.length > 0);
      setLoading(false);
      if (sorted.length === 0) {
        Alert.alert('No Route Found', 'No direct Golden Arrow route matches your journey.');
      }
    }, 800);
  };

  return (
    <ScrollView style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.title}>Find Your Route</Text>
        <Text style={styles.subtitle}>Golden Arrow Bus Services</Text>
      </View>

      <View style={styles.searchSection}>
        <View style={styles.inputContainer}>
          <Ionicons name="location" size={20} color="#f5576c" style={styles.icon} />
          <TextInput
            style={styles.input}
            placeholder="From (Your Location)"
            placeholderTextColor="rgba(255,255,255,0.5)"
            value={origin}
            onChangeText={setOrigin}
          />
          <TouchableOpacity onPress={getCurrentLocation}>
            <Ionicons name="navigate" size={20} color="#667eea" />
          </TouchableOpacity>
        </View>

        <View style={styles.inputContainer}>
          <Ionicons name="flag" size={20} color="#4CAF50" style={styles.icon} />
          <TextInput
            style={styles.input}
            placeholder="To (Destination)"
            placeholderTextColor="rgba(255,255,255,0.5)"
            value={destination}
            onChangeText={handleDestinationChange}
          />
        </View>

        {showSuggestions && suggestions.length > 0 && (
          <View style={styles.suggestionsBox}>
            {suggestions.map((suggestion, idx) => (
              <TouchableOpacity
                key={idx}
                style={styles.suggestionItem}
                onPress={() => selectSuggestion(suggestion)}
              >
                <Ionicons name="location" size={16} color="#667eea" />
                <Text style={styles.suggestionText}>{suggestion}</Text>
              </TouchableOpacity>
            ))}
          </View>
        )}

        <TouchableOpacity style={styles.findButton} onPress={() => findRoute()}>
          <Text style={styles.findButtonText}>{loading ? 'Searching...' : '🔍 Find Route'}</Text>
        </TouchableOpacity>
      </View>

      {showMap && matchedRoutes.length > 0 && (
        <View style={styles.mapContainer}>
          <MapView
            style={styles.map}
            region={region}
            showsUserLocation
            showsMyLocationButton
          >
            <Marker
              coordinate={{ latitude: -33.9249, longitude: 18.4241 }}
              title="Cape Town CBD"
              pinColor="#f5576c"
            />
          </MapView>
        </View>
      )}

      {matchedRoutes.length > 0 && (
        <View style={styles.resultsSection}>
          <Text style={styles.resultsTitle}>{matchedRoutes.length} Route{matchedRoutes.length > 1 ? 's' : ''} Found</Text>
          {matchedRoutes.map((route, index) => (
            <View key={index} style={styles.resultCard}>
              {index === 0 && (
                <View style={styles.recommendedBadge}>
                  <Text style={styles.recommendedText}>⚡ FASTEST</Text>
                </View>
              )}
              <View style={styles.resultHeader}>
                <Ionicons name="bus" size={32} color="#f5576c" />
                <View style={styles.resultHeaderText}>
                  <Text style={styles.busLabel}>{route.busLabel}</Text>
                  <Text style={styles.routeEndpoints}>{route.origin} → {route.endPoint}</Text>
                </View>
              </View>
              <View style={styles.routeStats}>
                <View style={styles.statItem}>
                  <Text style={styles.statValue}>{route.corridorNotes.length}</Text>
                  <Text style={styles.statLabel}>stops</Text>
                </View>
                <View style={styles.statItem}>
                  <Text style={styles.statValue}>{route.busLabel.includes('Express') ? 'Express' : 'Local'}</Text>
                  <Text style={styles.statLabel}>type</Text>
                </View>
              </View>
              <View style={styles.corridorSection}>
                <Text style={styles.corridorTitle}>Route Stops:</Text>
                {route.corridorNotes.map((note, idx) => (
                  <View key={idx} style={styles.stopItem}>
                    <View style={styles.stopDot} />
                    <Text style={styles.stopText}>{note}</Text>
                  </View>
                ))}
              </View>
            </View>
          ))}
        </View>
      )}

      <View style={styles.popularSection}>
        <Text style={styles.popularTitle}>Popular Destinations</Text>
        <View style={styles.popularGrid}>
          {POPULAR_DESTINATIONS.map((dest, idx) => (
            <TouchableOpacity
              key={idx}
              style={styles.popularChip}
              onPress={() => selectSuggestion(dest)}
            >
              <Text style={styles.popularChipText}>{dest}</Text>
            </TouchableOpacity>
          ))}
        </View>
      </View>

      <View style={{ height: 40 }} />
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#1a1a2e' },
  header: {
    backgroundColor: '#f5576c',
    paddingVertical: 30,
    paddingHorizontal: 20,
    paddingTop: 50,
  },
  title: { fontSize: 28, fontWeight: '900', color: '#fff', marginBottom: 5 },
  subtitle: { fontSize: 14, color: 'rgba(255,255,255,0.8)' },
  searchSection: { padding: 20 },
  inputContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'rgba(255,255,255,0.1)',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.2)',
    borderRadius: 16,
    paddingHorizontal: 15,
    paddingVertical: 12,
    marginBottom: 12,
  },
  icon: { marginRight: 10 },
  input: {
    flex: 1,
    fontSize: 16,
    color: '#fff',
  },
  suggestionsBox: {
    backgroundColor: 'rgba(255,255,255,0.1)',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.2)',
    borderRadius: 12,
    marginBottom: 12,
    maxHeight: 200,
  },
  suggestionItem: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 15,
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: 'rgba(255,255,255,0.1)',
  },
  suggestionText: { fontSize: 14, color: '#fff', marginLeft: 10 },
  findButton: {
    backgroundColor: '#667eea',
    paddingVertical: 16,
    borderRadius: 16,
    alignItems: 'center',
    marginTop: 8,
  },
  findButtonText: { fontSize: 18, fontWeight: '700', color: '#fff' },
  mapContainer: {
    height: 250,
    marginHorizontal: 20,
    marginBottom: 20,
    borderRadius: 20,
    overflow: 'hidden',
    borderWidth: 2,
    borderColor: 'rgba(255,255,255,0.2)',
  },
  map: {
    width: '100%',
    height: '100%',
  },
  resultsSection: { paddingHorizontal: 20, marginTop: 10 },
  resultsTitle: { fontSize: 16, fontWeight: '700', color: '#fff', marginBottom: 15 },
  resultCard: {
    marginBottom: 15,
    backgroundColor: 'rgba(255,255,255,0.1)',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.2)',
    borderRadius: 20,
    padding: 20,
  },
  resultHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 15,
    marginBottom: 20,
    paddingBottom: 15,
    borderBottomWidth: 1,
    borderBottomColor: 'rgba(255,255,255,0.1)',
  },
  resultHeaderText: { flex: 1 },
  busLabel: { fontSize: 20, fontWeight: '900', color: '#fff', marginBottom: 5 },
  routeEndpoints: { fontSize: 13, color: 'rgba(255,255,255,0.7)' },
  routeStats: {
    flexDirection: 'row',
    gap: 20,
    paddingVertical: 15,
    borderBottomWidth: 1,
    borderBottomColor: 'rgba(255,255,255,0.1)',
  },
  statItem: { alignItems: 'center' },
  statValue: { fontSize: 18, fontWeight: '900', color: '#667eea', marginBottom: 4 },
  statLabel: { fontSize: 11, color: 'rgba(255,255,255,0.6)' },
  corridorSection: { marginTop: 10 },
  corridorTitle: { fontSize: 14, fontWeight: '700', color: '#667eea', marginBottom: 12 },
  stopItem: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 10,
  },
  stopDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: '#f5576c',
    marginRight: 12,
  },
  stopText: { fontSize: 13, color: 'rgba(255,255,255,0.8)' },
  recommendedBadge: {
    position: 'absolute',
    top: 15,
    right: 15,
    backgroundColor: '#4CAF50',
    paddingHorizontal: 10,
    paddingVertical: 5,
    borderRadius: 12,
    zIndex: 10,
  },
  recommendedText: { fontSize: 11, fontWeight: '900', color: '#fff' },
  popularSection: { paddingHorizontal: 20, marginTop: 10 },
  popularTitle: { fontSize: 18, fontWeight: '700', color: '#fff', marginBottom: 15 },
  popularGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 10,
  },
  popularChip: {
    backgroundColor: 'rgba(102, 126, 234, 0.2)',
    borderWidth: 1,
    borderColor: 'rgba(102, 126, 234, 0.4)',
    paddingHorizontal: 16,
    paddingVertical: 10,
    borderRadius: 20,
  },
  popularChipText: { fontSize: 13, fontWeight: '600', color: '#667eea' },
});
