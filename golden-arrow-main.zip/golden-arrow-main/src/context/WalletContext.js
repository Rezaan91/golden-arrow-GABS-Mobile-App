import { createContext } from 'react';

export const WalletContext = createContext({
  walletState: {
    journeysRemaining: 0,
    ticketType: 'weekly',
    transferActive: false,
    transferExpiry: null,
  },
  setWalletState: () => {},
});
