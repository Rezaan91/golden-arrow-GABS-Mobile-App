import { createContext, useState, useEffect } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';

export const LanguageContext = createContext();

const translations = {
  en: {
    home: 'Home',
    routes: 'Routes',
    activity: 'Activity',
    community: 'Community',
    profile: 'Profile',
    journeysRemaining: 'Journeys Remaining',
    useJourney: 'Use Journey',
    buyJourneys: 'Buy Journeys',
    transferJourney: 'Transfer Journey',
    lowBalance: 'Low Balance Alert',
    lowBalanceMsg: 'journeys left. Consider buying more soon!',
    transferActive: 'Transfer Active',
    transferRemaining: 'transfer remaining',
    validFor: 'Valid for 2 hours from first boarding',
    weeklyTicket: 'Weekly Ticket',
    monthlyTicket: 'Monthly Ticket',
    signOut: 'Sign Out',
    language: 'Language',
    settings: 'Settings',
    account: 'Account',
    notifications: 'Notifications',
    emergencyHotline: 'Emergency Hotline',
    shareLocation: 'Share Location',
    trustedContacts: 'Trusted Contacts',
    serviceAlerts: 'Service Alerts',
  },
  af: {
    home: 'Tuis',
    routes: 'Roetes',
    activity: 'Aktiwiteit',
    community: 'Gemeenskap',
    profile: 'Profiel',
    journeysRemaining: 'Reise Oor',
    useJourney: 'Gebruik Reis',
    buyJourneys: 'Koop Reise',
    transferJourney: 'Oordrag Reis',
    lowBalance: 'Lae Balans Waarskuwing',
    lowBalanceMsg: 'reise oor. Oorweeg om meer te koop!',
    transferActive: 'Oordrag Aktief',
    transferRemaining: 'oordrag oor',
    validFor: 'Geldig vir 2 ure vanaf eerste instap',
    weeklyTicket: 'Weeklikse Kaartjie',
    monthlyTicket: 'Maandelikse Kaartjie',
    signOut: 'Teken Uit',
    language: 'Taal',
    settings: 'Instellings',
    account: 'Rekening',
    notifications: 'Kennisgewings',
    emergencyHotline: 'Noodlyn',
    shareLocation: 'Deel Ligging',
    trustedContacts: 'Vertroude Kontakte',
    serviceAlerts: 'Diens Waarskuwings',
  },
  xh: {
    home: 'Ikhaya',
    routes: 'Iindlela',
    activity: 'Umsebenzi',
    community: 'Uluntu',
    profile: 'Iprofayile',
    journeysRemaining: 'Uhambo Oluseleyo',
    useJourney: 'Sebenzisa Uhambo',
    buyJourneys: 'Thenga Uhambo',
    transferJourney: 'Dlulisela Uhambo',
    lowBalance: 'Ibalance Ephantsi',
    lowBalanceMsg: 'uhambo lusele. Cinga ngokuthenga ngakumbi!',
    transferActive: 'Ukudlulisela Kusebenza',
    transferRemaining: 'ukudlulisela kusele',
    validFor: 'Kusebenza iiyure ezi-2 ukusuka ekuqaleni',
    weeklyTicket: 'Itikiti Yeveki',
    monthlyTicket: 'Itikiti Yenyanga',
    signOut: 'Phuma',
    language: 'Ulwimi',
    settings: 'Iisetingi',
    account: 'I-akhawunti',
    notifications: 'Izaziso',
    emergencyHotline: 'Ucingo Lwengxaki',
    shareLocation: 'Yabelana Ngendawo',
    trustedContacts: 'Abantu Abathembekileyo',
    serviceAlerts: 'Izaziso Zenkonzo',
  }
};

export const LanguageProvider = ({ children }) => {
  const [language, setLanguage] = useState('en');

  useEffect(() => {
    AsyncStorage.getItem('language').then(lang => {
      if (lang) setLanguage(lang);
    });
  }, []);

  const changeLanguage = async (lang) => {
    setLanguage(lang);
    await AsyncStorage.setItem('language', lang);
  };

  const t = (key) => translations[language][key] || key;

  return (
    <LanguageContext.Provider value={{ language, changeLanguage, t }}>
      {children}
    </LanguageContext.Provider>
  );
};
