import { createContext } from 'react';

export const AuthContext = createContext({
  signIn: async (credentials) => {},
  signUp: async (userData) => {},
  signOut: async () => {},
  isAuthenticated: false,
});
