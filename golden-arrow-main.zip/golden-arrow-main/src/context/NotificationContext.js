import React, { createContext } from 'react';

export const NotificationContext = createContext({
  notifications: [],
  addNotification: (notification) => {},
  removeNotification: (id) => {},
  clearAll: () => {},
});
