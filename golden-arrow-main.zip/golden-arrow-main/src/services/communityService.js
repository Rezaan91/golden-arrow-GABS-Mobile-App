import { collection, getDocs, query, where, orderBy, limit, addDoc, doc, updateDoc, onSnapshot } from 'firebase/firestore';
import { db } from '../../firebaseConfig';

export const communityService = {
  // Get all communities
  getCommunities: async () => {
    try {
      const communitiesRef = collection(db, 'communities');
      const q = query(communitiesRef, orderBy('members', 'desc'));
      const snapshot = await getDocs(q);
      
      const communities = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      }));
      
      return { success: true, communities };
    } catch (error) {
      console.error('Get communities error:', error);
      return { success: false, error: error.message };
    }
  },

  // Get service alerts (real-time)
  subscribeToAlerts: (callback) => {
    try {
      const alertsRef = collection(db, 'serviceAlerts');
      const q = query(
        alertsRef,
        where('active', '==', true),
        orderBy('timestamp', 'desc'),
        limit(10)
      );
      
      const unsubscribe = onSnapshot(q, (snapshot) => {
        const alerts = snapshot.docs.map(doc => ({
          id: doc.id,
          ...doc.data()
        }));
        callback({ success: true, alerts });
      });
      
      return unsubscribe;
    } catch (error) {
      console.error('Subscribe to alerts error:', error);
      callback({ success: false, error: error.message });
      return () => {};
    }
  },

  // Share location
  shareLocation: async (userId, locationData) => {
    try {
      const { currentLocation, destination, trustedContacts, autoStop } = locationData;
      
      await addDoc(collection(db, 'liveLocations'), {
        userId,
        currentLocation,
        destination,
        trustedContacts,
        autoStop,
        active: true,
        startedAt: new Date().toISOString(),
        lastUpdated: new Date().toISOString()
      });
      
      return { success: true };
    } catch (error) {
      console.error('Share location error:', error);
      return { success: false, error: error.message };
    }
  },

  // Update location
  updateLocation: async (locationId, coordinates) => {
    try {
      await updateDoc(doc(db, 'liveLocations', locationId), {
        currentLocation: coordinates,
        lastUpdated: new Date().toISOString()
      });
      
      return { success: true };
    } catch (error) {
      console.error('Update location error:', error);
      return { success: false, error: error.message };
    }
  },

  // Stop sharing location
  stopSharing: async (locationId) => {
    try {
      await updateDoc(doc(db, 'liveLocations', locationId), {
        active: false,
        stoppedAt: new Date().toISOString()
      });
      
      return { success: true };
    } catch (error) {
      console.error('Stop sharing error:', error);
      return { success: false, error: error.message };
    }
  },

  // Add trusted contact
  addTrustedContact: async (userId, contactData) => {
    try {
      const { name, phone, relationship } = contactData;
      
      await addDoc(collection(db, 'users', userId, 'trustedContacts'), {
        name,
        phone,
        relationship,
        addedAt: new Date().toISOString()
      });
      
      return { success: true };
    } catch (error) {
      console.error('Add contact error:', error);
      return { success: false, error: error.message };
    }
  },

  // Get trusted contacts
  getTrustedContacts: async (userId) => {
    try {
      const contactsRef = collection(db, 'users', userId, 'trustedContacts');
      const snapshot = await getDocs(contactsRef);
      
      const contacts = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      }));
      
      return { success: true, contacts };
    } catch (error) {
      console.error('Get contacts error:', error);
      return { success: false, error: error.message };
    }
  }
};
