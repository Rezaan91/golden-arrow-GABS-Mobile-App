import routeData from '../data/routes.json';

const normalizeText = (text) => {
  return text.toLowerCase().trim().replace(/[^a-z0-9\s]/g, '');
};

const matchDestination = (input) => {
  const normalized = normalizeText(input);
  
  // City/Cape Town keywords
  if (normalized.includes('cape town') || normalized.includes('city') || 
      normalized.includes('station') || normalized.includes('cbd') ||
      normalized.includes('long street') || normalized.includes('waterfront')) {
    return 'city';
  }
  
  // Bellville keywords
  if (normalized.includes('bellville') || normalized.includes('tygervalley') ||
      normalized.includes('durbanville')) {
    return 'bellville';
  }
  
  // Observatory/UCT
  if (normalized.includes('observatory') || normalized.includes('uct') ||
      normalized.includes('groote schuur')) {
    return 'city'; // City routes via Observatory
  }
  
  // Mowbray/CPUT
  if (normalized.includes('mowbray') || normalized.includes('cput') ||
      normalized.includes('rondebosch')) {
    return 'city'; // City routes via Mowbray
  }
  
  return null;
};

export const findRoutes = (startAddress, destination) => {
  const destType = matchDestination(destination);
  
  if (!destType) {
    return {
      error: 'Destination not recognized. Try: Cape Town, Bellville, Observatory, Mowbray',
      suggestions: []
    };
  }
  
  let routes = [];
  
  if (destType === 'city') {
    routes = routeData.routes.khayelitsha_to_city;
  } else if (destType === 'bellville') {
    routes = routeData.routes.khayelitsha_to_bellville;
  }
  
  // Sort by average time (fastest first)
  routes = routes.sort((a, b) => a.avgTime - b.avgTime);
  
  // Mark recommended (fastest freeway option)
  const freewayRoutes = routes.filter(r => r.type === 'freeway');
  if (freewayRoutes.length > 0) {
    routes = routes.map(r => ({
      ...r,
      recommended: r.id === freewayRoutes[0].id
    }));
  }
  
  return {
    destination: destType,
    routes: routes,
    totalOptions: routes.length
  };
};

export const getRouteDetails = (routeId) => {
  const allRoutes = [
    ...routeData.routes.khayelitsha_to_city,
    ...routeData.routes.khayelitsha_to_bellville
  ];
  
  return allRoutes.find(r => r.id === routeId);
};
