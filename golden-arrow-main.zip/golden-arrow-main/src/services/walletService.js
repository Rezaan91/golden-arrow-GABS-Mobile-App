import { doc, getDoc, updateDoc, setDoc, collection, addDoc, query, where, orderBy, limit, getDocs } from 'firebase/firestore';
import { db } from '../../firebaseConfig';
import AsyncStorage from '@react-native-async-storage/async-storage';

export const walletService = {
  // Get wallet data
  getWallet: async (userId) => {
    try {
      const userDoc = await getDoc(doc(db, 'users', userId));
      if (userDoc.exists()) {
        const wallet = userDoc.data().wallet;
        // Cache in AsyncStorage
        await AsyncStorage.setItem('walletState', JSON.stringify(wallet));
        return { success: true, wallet };
      }
      return { success: false, error: 'User not found' };
    } catch (error) {
      console.error('Get wallet error:', error);
      // Try to get from AsyncStorage if offline
      const cached = await AsyncStorage.getItem('walletState');
      if (cached) {
        return { success: true, wallet: JSON.parse(cached), cached: true };
      }
      return { success: false, error: error.message };
    }
  },

  // Buy journeys
  buyJourneys: async (userId, packageData) => {
    try {
      const { journeys, price, type } = packageData;
      
      // Create payment record
      const paymentRef = await addDoc(collection(db, 'payments'), {
        userId,
        amount: price,
        journeys,
        packageType: type,
        status: 'completed',
        paymentMethod: 'demo',
        timestamp: new Date().toISOString()
      });
      
      // Update wallet
      const userRef = doc(db, 'users', userId);
      const userDoc = await getDoc(userRef);
      if (!userDoc.exists()) {
        return { success: false, error: 'User not found', code: 'USER_NOT_FOUND' };
      }
      
      const currentWallet = userDoc.data().wallet || { journeysRemaining: 0, totalSpent: 0 };
      const newBalance = currentWallet.journeysRemaining + journeys;
      
      await updateDoc(userRef, {
        'wallet.journeysRemaining': newBalance,
        'wallet.ticketType': type,
        'wallet.totalSpent': (currentWallet.totalSpent || 0) + price
      });
      
      // Add to history
      await addDoc(collection(db, 'users', userId, 'history'), {
        type: 'purchase',
        amount: journeys,
        price,
        packageType: type,
        timestamp: new Date().toISOString(),
        paymentId: paymentRef.id
      });
      
      return { 
        success: true, 
        message: `Payment successful! ${journeys} journey${journeys > 1 ? 's' : ''} added to your wallet`,
        paymentId: paymentRef.id,
        journeysRemaining: newBalance,
        amountPaid: price,
        code: 'PAYMENT_SUCCESS'
      };
    } catch (error) {
      console.error('Buy journeys error:', error);
      return { success: false, error: error.message, code: 'PAYMENT_FAILED' };
    }
  },

  // Use journey
  useJourney: async (userId, routeInfo = {}) => {
    try {
      const userRef = doc(db, 'users', userId);
      const userDoc = await getDoc(userRef);
      if (!userDoc.exists()) {
        return { success: false, error: 'User not found', code: 'USER_NOT_FOUND' };
      }
      
      const wallet = userDoc.data().wallet;
      if (wallet.journeysRemaining <= 0) {
        return { 
          success: false, 
          error: 'No journeys remaining. Please buy more journeys.',
          code: 'NO_JOURNEYS'
        };
      }
      
      const newBalance = wallet.journeysRemaining - 1;
      
      // Update wallet
      await updateDoc(userRef, {
        'wallet.journeysRemaining': newBalance,
        'wallet.transferActive': true,
        'wallet.transferExpiry': Date.now() + 7200000
      });
      
      // Add to history
      await addDoc(collection(db, 'users', userId, 'history'), {
        type: 'journey',
        route: routeInfo.route || 'Unknown',
        from: routeInfo.from || 'Unknown',
        to: routeInfo.to || 'Unknown',
        cost: 1,
        timestamp: new Date().toISOString()
      });
      
      return { 
        success: true, 
        message: 'Journey activated! You have 2 hours for transfers.',
        journeysRemaining: newBalance,
        transferExpiry: Date.now() + 7200000,
        code: 'JOURNEY_ACTIVATED'
      };
    } catch (error) {
      console.error('Use journey error:', error);
      return { success: false, error: error.message, code: 'JOURNEY_ERROR' };
    }
  },

  // Transfer journeys
  transferJourneys: async (fromUserId, transferData) => {
    try {
      const { recipient, recipientType, quantity } = transferData;
      
      // Get sender wallet
      const userRef = doc(db, 'users', fromUserId);
      const userDoc = await getDoc(userRef);
      if (!userDoc.exists()) {
        return { success: false, error: 'Sender account not found', code: 'SENDER_NOT_FOUND' };
      }
      
      const wallet = userDoc.data().wallet;
      if (wallet.journeysRemaining < quantity) {
        return { 
          success: false, 
          error: `Insufficient journeys. You have ${wallet.journeysRemaining}, need ${quantity}`,
          code: 'INSUFFICIENT_BALANCE'
        };
      }
      
      // Find recipient by phone or card
      let recipientId = null;
      const usersRef = collection(db, 'users');
      const q = recipientType === 'phone' 
        ? query(usersRef, where('phone', '==', recipient), limit(1))
        : query(usersRef, where('wallet.cardNumber', '==', recipient), limit(1));
      
      const recipientSnapshot = await getDocs(q);
      if (recipientSnapshot.empty) {
        return { 
          success: false, 
          error: `Recipient ${recipientType === 'phone' ? 'phone number' : 'card'} not found. They must have an account.`,
          code: 'RECIPIENT_NOT_FOUND'
        };
      }
      
      recipientId = recipientSnapshot.docs[0].id;
      const recipientData = recipientSnapshot.docs[0].data();
      
      // Deduct from sender
      await updateDoc(userRef, {
        'wallet.journeysRemaining': wallet.journeysRemaining - quantity
      });
      
      // Add to recipient
      const recipientRef = doc(db, 'users', recipientId);
      await updateDoc(recipientRef, {
        'wallet.journeysRemaining': (recipientData.wallet?.journeysRemaining || 0) + quantity
      });
      
      // Create transfer record
      const transferRef = await addDoc(collection(db, 'transfers'), {
        from: fromUserId,
        to: recipientId,
        recipient,
        recipientType,
        quantity,
        timestamp: new Date().toISOString(),
        status: 'completed'
      });
      
      // Add to both histories
      await addDoc(collection(db, 'users', fromUserId, 'history'), {
        type: 'transfer',
        direction: 'sent',
        recipient,
        quantity,
        timestamp: new Date().toISOString(),
        referenceId: transferRef.id
      });
      
      await addDoc(collection(db, 'users', recipientId, 'history'), {
        type: 'transfer',
        direction: 'received',
        from: userDoc.data().phone || 'Unknown',
        quantity,
        timestamp: new Date().toISOString(),
        referenceId: transferRef.id
      });
      
      return { 
        success: true, 
        message: `Successfully transferred ${quantity} journey${quantity > 1 ? 's' : ''} to ${recipient}`,
        referenceId: transferRef.id,
        journeysRemaining: wallet.journeysRemaining - quantity,
        code: 'TRANSFER_SUCCESS'
      };
    } catch (error) {
      console.error('Transfer error:', error);
      return { success: false, error: error.message, code: 'TRANSFER_ERROR' };
    }
  },

  // Get history
  getHistory: async (userId, limitCount = 50) => {
    try {
      const historyRef = collection(db, 'users', userId, 'history');
      const q = query(historyRef, orderBy('timestamp', 'desc'), limit(limitCount));
      const snapshot = await getDocs(q);
      
      const history = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      }));
      
      // Cache in AsyncStorage
      await AsyncStorage.setItem('journeyHistory', JSON.stringify(history));
      
      return { success: true, history };
    } catch (error) {
      console.error('Get history error:', error);
      // Try cached data
      const cached = await AsyncStorage.getItem('journeyHistory');
      if (cached) {
        return { success: true, history: JSON.parse(cached), cached: true };
      }
      return { success: false, error: error.message };
    }
  },

  // Link card
  linkCard: async (userId, cardData) => {
    try {
      const { cardNumber, expiryDate } = cardData;
      
      await setDoc(doc(db, 'users', userId, 'cards', cardNumber), {
        cardNumber,
        expiryDate,
        linkedAt: new Date().toISOString(),
        active: true
      });
      
      return { success: true };
    } catch (error) {
      console.error('Link card error:', error);
      return { success: false, error: error.message };
    }
  }
};
