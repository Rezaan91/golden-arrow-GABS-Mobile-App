import { 
  createUserWithEmailAndPassword, 
  signInWithEmailAndPassword,
  signOut as firebaseSignOut,
  sendPasswordResetEmail
} from 'firebase/auth';
import { doc, setDoc, getDoc, collection, query, where, getDocs } from 'firebase/firestore';
import { auth, db } from '../../firebaseConfig';
import AsyncStorage from '@react-native-async-storage/async-storage';

export const authService = {
  signUp: async (userData) => {
    try {
      const { firstName, surname, phone, email, password } = userData;
      
      let user;
      if (email && password) {
        const userCredential = await createUserWithEmailAndPassword(auth, email, password);
        user = userCredential.user;
      } else {
        const tempEmail = `${phone}@goldenarrow.temp`;
        const tempPassword = Math.random().toString(36).slice(-12);
        const userCredential = await createUserWithEmailAndPassword(auth, tempEmail, tempPassword);
        user = userCredential.user;
      }
      
      await setDoc(doc(db, 'users', user.uid), {
        firstName,
        surname,
        phone,
        email: email || null,
        language: 'en',
        createdAt: new Date().toISOString(),
        wallet: {
          journeysRemaining: 0,
          ticketType: null,
          transferActive: false,
          transferExpiry: null,
          totalSpent: 0
        }
      });
      
      await AsyncStorage.setItem('userToken', user.uid);
      await AsyncStorage.setItem('userData', JSON.stringify({
        uid: user.uid,
        phone,
        email: email || null,
        firstName,
        surname
      }));
      
      return { success: true, user };
    } catch (error) {
      console.error('Signup error:', error);
      return { success: false, error: error.message };
    }
  },

  signIn: async (identifier, password) => {
    try {
      const isPhone = /^\d{10}$/.test(identifier);
      let email = identifier;
      
      if (isPhone) {
        const usersRef = collection(db, 'users');
        const q = query(usersRef, where('phone', '==', identifier));
        const snapshot = await getDocs(q);
        
        if (snapshot.empty) {
          return { success: false, error: 'Phone number not found' };
        }
        
        const userData = snapshot.docs[0].data();
        email = userData.email || `${identifier}@goldenarrow.temp`;
      }
      
      const userCredential = await signInWithEmailAndPassword(auth, email, password);
      const user = userCredential.user;
      
      const userDoc = await getDoc(doc(db, 'users', user.uid));
      const userData = userDoc.data();
      
      await AsyncStorage.setItem('userToken', user.uid);
      await AsyncStorage.setItem('userData', JSON.stringify({
        uid: user.uid,
        ...userData
      }));
      
      return { success: true, user, userData };
    } catch (error) {
      console.error('Login error:', error);
      return { success: false, error: error.message };
    }
  },

  signOut: async () => {
    try {
      await firebaseSignOut(auth);
      await AsyncStorage.removeItem('userToken');
      await AsyncStorage.removeItem('userData');
      await AsyncStorage.removeItem('walletState');
      return { success: true };
    } catch (error) {
      console.error('Signout error:', error);
      return { success: false, error: error.message };
    }
  },

  sendOTP: async (phoneNumber) => {
    const otp = Math.floor(100000 + Math.random() * 900000).toString();
    console.log(`OTP for ${phoneNumber}: ${otp}`);
    
    setDoc(doc(db, 'otps', phoneNumber), {
      code: otp,
      expiresAt: Date.now() + 300000,
      createdAt: new Date().toISOString()
    }).catch(err => console.log('Firestore write failed:', err));
    
    return { success: true };
  },

  verifyOTP: async (phoneNumber, code) => {
    try {
      const otpDoc = await getDoc(doc(db, 'otps', phoneNumber));
      
      if (!otpDoc.exists()) {
        return { success: false, error: 'OTP not found' };
      }
      
      const otpData = otpDoc.data();
      
      if (Date.now() > otpData.expiresAt) {
        return { success: false, error: 'OTP expired' };
      }
      
      if (otpData.code !== code) {
        return { success: false, error: 'Invalid OTP' };
      }
      
      return { success: true };
    } catch (error) {
      console.error('OTP verification error:', error);
      return { success: false, error: error.message };
    }
  },

  resetPassword: async (email) => {
    try {
      await sendPasswordResetEmail(auth, email);
      return { success: true };
    } catch (error) {
      console.error('Password reset error:', error);
      return { success: false, error: error.message };
    }
  },

  getCurrentUser: () => {
    return auth.currentUser;
  }
};
