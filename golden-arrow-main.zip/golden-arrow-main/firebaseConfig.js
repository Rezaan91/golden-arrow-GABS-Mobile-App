import { initializeApp } from 'firebase/app';
import { getAuth } from 'firebase/auth';
import { getFirestore } from 'firebase/firestore';
import { getStorage } from 'firebase/storage';

const firebaseConfig = {
  apiKey: "AIzaSyA8sxs7JH4N6OG-Rae1yJoK6pzkYJ6d2A4",
  authDomain: "golden-arrow-app-1a9a9.firebaseapp.com",
  projectId: "golden-arrow-app-1a9a9",
  storageBucket: "golden-arrow-app-1a9a9.firebasestorage.app",
  messagingSenderId: "700377984964",
  appId: "1:700377984964:web:57fcc8898afed150127e91"
};

const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
export const db = getFirestore(app);
export const storage = getStorage(app);

export default app;
