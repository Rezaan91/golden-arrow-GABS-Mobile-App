import React, { useEffect, useState } from 'react';
import { StatusBar } from 'expo-status-bar';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { Ionicons } from '@expo/vector-icons';
import { AuthContext } from './src/context/AuthContext';
import { WalletContext } from './src/context/WalletContext';

// Screens
import SplashScreen from './src/screens/SplashScreen';
import LoginScreen from './src/screens/auth/LoginScreen';
import SignupScreen from './src/screens/auth/SignupScreen';
import VerifyOTPScreen from './src/screens/auth/VerifyOTPScreen';
import CardLinkingScreen from './src/screens/auth/CardLinkingScreen';
import WalletScreen from './src/screens/wallet/WalletScreen';
import BuyJourneysScreen from './src/screens/wallet/BuyJourneysScreen';
import TransferJourneyScreen from './src/screens/wallet/TransferJourneyScreen';
import JourneyHistoryScreen from './src/screens/wallet/JourneyHistoryScreen';
import QRScannerScreen from './src/screens/wallet/QRScannerScreen';
import RouteFinderScreen from './src/screens/routes/RouteFinderScreen';
import CommunityScreen from './src/screens/community/CommunityScreen';
import ShareLocationScreen from './src/screens/community/ShareLocationScreen';
import SettingsScreen from './src/screens/settings/SettingsScreen';
import { LanguageProvider } from './src/context/LanguageContext';

const Stack = createNativeStackNavigator();
const Tab = createBottomTabNavigator();

const AuthStack = () => (
  <Stack.Navigator screenOptions={{ headerShown: false }}>
    <Stack.Screen name="Splash" component={SplashScreen} />
    <Stack.Screen name="Login" component={LoginScreen} />
    <Stack.Screen name="Signup" component={SignupScreen} />
    <Stack.Screen name="VerifyOTP" component={VerifyOTPScreen} />
    <Stack.Screen name="CardLinking" component={CardLinkingScreen} />
  </Stack.Navigator>
);

const WalletStack = () => (
  <Stack.Navigator screenOptions={{ headerStyle: { backgroundColor: '#1a1a2e' }, headerTintColor: '#fff' }}>
    <Stack.Screen name="WalletHome" component={WalletScreen} options={{ title: 'My Journeys' }} />
    <Stack.Screen name="BuyJourneys" component={BuyJourneysScreen} options={{ title: 'Buy Journeys' }} />
    <Stack.Screen name="TransferJourney" component={TransferJourneyScreen} options={{ title: 'Transfer Journey' }} />
    <Stack.Screen name="QRScanner" component={QRScannerScreen} options={{ headerShown: false }} />
  </Stack.Navigator>
);

const CommunityStack = () => (
  <Stack.Navigator screenOptions={{ headerStyle: { backgroundColor: '#1a1a2e' }, headerTintColor: '#fff' }}>
    <Stack.Screen name="CommunityHome" component={CommunityScreen} options={{ title: 'Community' }} />
    <Stack.Screen name="ShareLocation" component={ShareLocationScreen} options={{ title: 'Share Location' }} />
  </Stack.Navigator>
);

const AppStack = () => (
  <Tab.Navigator
    screenOptions={{
      headerShown: false,
      tabBarStyle: {
        backgroundColor: 'rgba(26, 26, 46, 0.95)',
        borderTopWidth: 1,
        borderTopColor: 'rgba(255, 255, 255, 0.1)',
        paddingBottom: 8,
        paddingTop: 8,
        height: 65,
      },
      tabBarActiveTintColor: '#f5576c',
      tabBarInactiveTintColor: 'rgba(255, 255, 255, 0.5)',
      tabBarLabelStyle: {
        fontSize: 10,
        fontWeight: '600',
      },
    }}
  >
    <Tab.Screen 
      name="Home" 
      component={WalletStack} 
      options={{
        tabBarLabel: 'Home',
        tabBarIcon: ({ color, size }) => <Ionicons name="home" size={24} color={color} />
      }} 
    />
    <Tab.Screen 
      name="Routes" 
      component={RouteFinderScreen} 
      options={{
        tabBarLabel: 'Routes',
        tabBarIcon: ({ color, size }) => <Ionicons name="bus" size={24} color={color} />
      }} 
    />
    <Tab.Screen 
      name="Community" 
      component={CommunityStack} 
      options={{
        tabBarLabel: 'Community',
        tabBarIcon: ({ color, size }) => <Ionicons name="people" size={24} color={color} />
      }} 
    />
    <Tab.Screen 
      name="Activity" 
      component={JourneyHistoryScreen} 
      options={{
        tabBarLabel: 'Activity',
        tabBarIcon: ({ color, size }) => <Ionicons name="pulse" size={24} color={color} />
      }} 
    />
    <Tab.Screen 
      name="Profile" 
      component={SettingsScreen} 
      options={{
        tabBarLabel: 'Profile',
        tabBarIcon: ({ color, size }) => <Ionicons name="person" size={24} color={color} />
      }} 
    />
  </Tab.Navigator>
);

export default function App() {
  const [state, dispatch] = React.useReducer(
    (prevState, action) => {
      switch (action.type) {
        case 'RESTORE_TOKEN':
          return { ...prevState, isLoading: false, userToken: action.payload };
        case 'SIGN_IN':
          return { ...prevState, isSignout: false, userToken: action.payload };
        case 'SIGN_OUT':
          return { ...prevState, isSignout: true, userToken: null };
        default:
          return prevState;
      }
    },
    { isLoading: true, isSignout: false, userToken: null }
  );

  const [walletState, setWalletState] = useState({
    journeysRemaining: 0,
    ticketType: null,
    transferActive: false,
    transferExpiry: null,
    cardNumber: null,
    history: [],
  });

  useEffect(() => {
    const loadData = async () => {
      try {
        const token = await AsyncStorage.getItem('userToken');
        const wallet = await AsyncStorage.getItem('walletState');
        if (wallet) setWalletState(JSON.parse(wallet));
        dispatch({ type: 'RESTORE_TOKEN', payload: token });
      } catch (e) {
        dispatch({ type: 'RESTORE_TOKEN', payload: null });
      }
    };
    loadData();
  }, []);

  useEffect(() => {
    if (state.userToken) {
      AsyncStorage.setItem('walletState', JSON.stringify(walletState));
    }
  }, [walletState]);

  const authContext = React.useMemo(
    () => ({
      signIn: async (credentials) => {
        await AsyncStorage.setItem('userToken', 'user-token');
        dispatch({ type: 'SIGN_IN', payload: 'user-token' });
      },
      signUp: async (userData) => {
        await AsyncStorage.setItem('userToken', 'user-token');
        await AsyncStorage.setItem('userData', JSON.stringify(userData));
        dispatch({ type: 'SIGN_IN', payload: 'user-token' });
      },
      signOut: async () => {
        await AsyncStorage.removeItem('userToken');
        await AsyncStorage.removeItem('activeShare');
        dispatch({ type: 'SIGN_OUT' });
      },
    }),
    []
  );

  return (
    <LanguageProvider>
      <AuthContext.Provider value={authContext}>
        <WalletContext.Provider value={{ walletState, setWalletState }}>
          <NavigationContainer>
          <StatusBar style="light" />
          {state.isLoading ? (
            <Stack.Navigator screenOptions={{ headerShown: false }}>
              <Stack.Screen name="Splash" component={SplashScreen} />
            </Stack.Navigator>
          ) : state.userToken == null ? (
            <AuthStack />
          ) : (
            <AppStack />
          )}
          </NavigationContainer>
        </WalletContext.Provider>
      </AuthContext.Provider>
    </LanguageProvider>
  );
}
